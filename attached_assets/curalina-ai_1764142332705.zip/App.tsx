
import React, { useState, useEffect } from 'react';
import { DesignQuiz } from './components/DesignQuiz';
import { ProductCard } from './components/ProductCard';
import { AdminDashboard } from './components/AdminDashboard';
import { AdminLogin } from './components/AdminLogin';
import { generateRoomRender, analyzeRoomImage } from './services/geminiService';
import { selectBestFitProducts } from './services/productMatcher'; // Import Matcher
import { db } from './services/db';
import { 
  QuizState, 
  Product, 
  ViewState, 
  CartItem, 
  GeneratedDesign, 
  DesignStatus,
  User,
  Order,
  Supplier,
  RenderLog
} from './types';
import { 
  ShoppingBag, ArrowRight, Sparkles, Sofa, 
  User as UserIcon, Trash2, Menu, Lock
} from 'lucide-react';

type ExtendedViewState = ViewState | 'admin';

const App: React.FC = () => {
  const [view, setView] = useState<ExtendedViewState>('landing');
  const [hasApiKey, setHasApiKey] = useState(false);

  // Data State
  const [products, setProducts] = useState<Product[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [renders, setRenders] = useState<RenderLog[]>([]);
  const [dbLoaded, setDbLoaded] = useState(false);
  
  // Authentication
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(() => {
    return localStorage.getItem('curalina_admin_session') === 'true';
  });

  // Design Process State
  const [quizState, setQuizState] = useState<QuizState | null>(null);
  const [designStatus, setDesignStatus] = useState<DesignStatus>('idle');
  const [generatedDesign, setGeneratedDesign] = useState<GeneratedDesign | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [recommendedProducts, setRecommendedProducts] = useState<Product[]>([]);

  // --- Effects ---

  useEffect(() => {
    const checkApiKey = async () => {
      if (window.aistudio && window.aistudio.hasSelectedApiKey) {
        const hasKey = await window.aistudio.hasSelectedApiKey();
        setHasApiKey(hasKey);
      } else {
        setHasApiKey(true);
      }
    };
    checkApiKey();
  }, []);

  const handleSelectKey = async () => {
    if (window.aistudio && window.aistudio.openSelectKey) {
      await window.aistudio.openSelectKey();
      setHasApiKey(true);
    }
  };

  useEffect(() => {
    const initData = async () => {
      await db.init();
      const [p, u, o, s, r] = await Promise.all([
        db.products.getAll(),
        db.users.getAll(),
        db.orders.getAll(),
        db.suppliers.getAll(),
        db.renders.getAll()
      ]);
      setProducts(p);
      setUsers(u);
      setOrders(o);
      setSuppliers(s);
      setRenders(r);
      setDbLoaded(true);
    };
    initData();
  }, []);

  useEffect(() => {
    const savedCart = localStorage.getItem('curalina_cart');
    if (savedCart) setCart(JSON.parse(savedCart));
  }, []);

  useEffect(() => {
    localStorage.setItem('curalina_cart', JSON.stringify(cart));
  }, [cart]);

  // --- Logic ---

  const handleQuizComplete = async (state: QuizState) => {
    setQuizState(state);
    setView('loading');
    setDesignStatus('analyzing_room');

    try {
      // 1. Intelligent Product Selection (Updated)
      // Use the new matcher service instead of random filtering
      const matchedProducts = selectBestFitProducts(products, state);
      
      // Fallback if matcher returns nothing (shouldn't happen with initialized data, but safety check)
      const finalSelection = matchedProducts.length > 0 ? matchedProducts : products.slice(0, 4);
      
      setRecommendedProducts(finalSelection);

      // 2. Room Analysis (Structure Preservation)
      let structureDesc = "";
      if (state.roomImage) {
        structureDesc = await analyzeRoomImage(state.roomImage);
      }
      
      setDesignStatus('generating');

      // 3. Generate Design with High Fidelity
      // We pass the matched products so Gemini uses their specific images in the render
      const { imageUrl, prompt } = await generateRoomRender(state, finalSelection, structureDesc);
      
      // 4. Log and Save
      const newLog: RenderLog = {
        id: crypto.randomUUID(),
        userId: 'guest',
        prompt: prompt.substring(0, 100) + '...',
        imageUrl,
        date: new Date().toLocaleString(),
        status: 'success',
        roomType: state.roomType || 'Unknown'
      };
      const updatedRenders = await db.renders.add(newLog);
      setRenders(updatedRenders);

      setGeneratedDesign({
        id: crypto.randomUUID(),
        imageUrl,
        products: finalSelection, // Ensures Results Page shows EXACTLY what was used
        promptUsed: prompt,
        createdAt: Date.now()
      });

      setDesignStatus('complete');
      setView('results');

    } catch (e) {
      console.error(e);
      setDesignStatus('failed');
      setTimeout(() => setView('quiz'), 2000); 
    }
  };

  const handleAddProduct = async (newProduct: Product) => {
    const updated = await db.products.add(newProduct);
    setProducts(updated);
  };

  const handleBulkAddProducts = async (newProducts: Product[]) => {
    const updated = await db.products.bulkAdd(newProducts);
    setProducts(updated);
  };

  const handleBulkUpsertProducts = async (newProducts: Product[]) => {
    const updated = await db.products.bulkUpsert(newProducts);
    setProducts(updated);
  };

  const handleAddUser = async (newUser: User) => {
    const updated = await db.users.add(newUser);
    setUsers(updated);
  };

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(p => p.id === product.id);
      if (existing) {
        return prev.map(p => p.id === product.id ? { ...p, quantity: p.quantity + 1 } : p);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(p => p.id !== id));
  };

  const getCartTotal = () => {
    return cart.reduce((sum, item) => sum + ((item.salePrice || item.price) * item.quantity), 0);
  };

  const handleAdminLogin = () => {
    localStorage.setItem('curalina_admin_session', 'true');
    setIsAdminAuthenticated(true);
  };

  const handleAdminLogout = () => {
    localStorage.removeItem('curalina_admin_session');
    setIsAdminAuthenticated(false);
    setView('landing');
  };

  const handleCheckout = async () => {
     if (cart.length === 0) return;
     const newOrder: Order = {
       id: `ORD-${Math.floor(Math.random() * 10000)}`,
       customerName: 'Guest Customer',
       email: 'guest@example.com',
       date: new Date().toISOString().split('T')[0],
       total: Math.round(getCartTotal() * 1.08),
       status: 'Pending',
       itemsCount: cart.reduce((a, b) => a + b.quantity, 0)
     };
     const updatedOrders = await db.orders.add(newOrder);
     setOrders(updatedOrders);
     setCart([]);
     alert('Order Placed! View in Admin Dashboard.');
     setView('landing');
  };

  // --- Views Logic (Extracted for readability) ---

  const renderHeader = () => (
    <header className="sticky top-0 z-50 bg-card/90 backdrop-blur-md border-b border-slate-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        <div 
          className="flex items-center gap-2 cursor-pointer" 
          onClick={() => setView('landing')}
        >
          <div className="w-8 h-8 bg-gradient-to-br from-curalina-500 to-curalina-600 rounded-lg flex items-center justify-center text-white font-bold text-xl shadow-sm">C</div>
          <span className="font-bold text-slate-900 text-lg tracking-tight">Curalina AI</span>
        </div>
        
        <nav className="hidden lg:flex items-center gap-6 ml-8">
          <button 
             onClick={() => setView('landing')} 
             className={`text-sm font-medium transition-colors ${view === 'landing' ? 'text-curalina-600 font-semibold' : 'text-slate-600 hover:text-slate-900'}`}
          >
             How it works
          </button>
          <button className="text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors">Styles</button>
          <button className="text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors">Pricing</button>
          <button 
             onClick={() => setView('marketplace')} 
             className={`text-sm font-medium transition-colors ${view === 'marketplace' ? 'text-curalina-600 font-semibold' : 'text-slate-600 hover:text-slate-900'}`}
          >
             The Edit
          </button>
        </nav>

        <div className="flex items-center gap-4 ml-auto">
          <button 
            onClick={() => setView('admin')} 
            className="hidden sm:block text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors"
          >
            Sign in
          </button>
          <button 
             onClick={() => setView('quiz')}
             className="bg-slate-900 text-white px-5 py-2.5 rounded-full text-sm font-medium hover:bg-slate-800 transition-all shadow-sm transform hover:-translate-y-0.5"
           >
             Start the Quiz
           </button>
          <button onClick={() => setView('cart')} className="relative p-2 text-slate-600 hover:text-slate-900 transition-colors hover:bg-slate-100 rounded-full">
            <ShoppingBag className="w-5 h-5" />
            {cart.length > 0 && (
              <span className="absolute top-0 right-0 w-4 h-4 bg-curalina-500 text-white text-[10px] font-bold flex items-center justify-center rounded-full animate-in zoom-in border border-white">
                {cart.reduce((a, b) => a + b.quantity, 0)}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );

  const renderLanding = () => (
    <div className="animate-in fade-in duration-700">
      <div className="relative overflow-hidden bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 py-24 sm:px-6 lg:py-32 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-curalina-100 text-curalina-800 text-xs font-semibold uppercase tracking-wide mb-6 border border-curalina-200">
              <Sparkles className="w-3 h-3" /> AI-Powered Interior Design
            </div>
            <h1 className="text-5xl lg:text-6xl font-bold tracking-tight text-slate-900 mb-6 leading-tight">
              Design your dream space in <span className="text-transparent bg-clip-text bg-gradient-to-r from-curalina-600 to-curalina-500">seconds.</span>
            </h1>
            <p className="text-xl text-slate-600 mb-8 leading-relaxed max-w-lg">
              Upload a photo of your room. Tell us your vibe. Watch as hybrid AI transforms your space with real, shoppable furniture.
            </p>
            <div className="flex gap-4">
              <button 
                onClick={() => setView('quiz')}
                className="bg-slate-900 text-white px-8 py-4 rounded-xl font-semibold text-lg hover:bg-slate-800 transition-all shadow-lg hover:shadow-xl hover:-translate-y-1 flex items-center gap-2"
              >
                Start Your Design <ArrowRight className="w-5 h-5" />
              </button>
              <button 
                onClick={() => setView('marketplace')}
                className="bg-card text-slate-900 border border-slate-200 px-8 py-4 rounded-xl font-semibold text-lg hover:bg-slate-100 transition-all"
              >
                Explore Shop
              </button>
            </div>
          </div>
          <div className="relative">
             <div className="absolute inset-0 bg-gradient-to-tr from-curalina-200/50 to-purple-200/50 rounded-3xl transform rotate-3 blur-3xl opacity-30"></div>
             <img 
               src="https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1200&q=80" 
               className="relative rounded-3xl shadow-2xl transform -rotate-2 hover:rotate-0 transition-transform duration-700 border-4 border-white"
               alt="Modern Interior"
             />
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 py-24">
        <div className="text-center max-w-2xl mx-auto mb-16">
           <h2 className="text-3xl font-bold text-slate-900 mb-4">How Curalina Works</h2>
           <p className="text-slate-600">From inspiration to installation, we handle the complex design work so you can focus on living.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
           {[
             { title: "Share Your Vibe", desc: "Upload inspiration photos or take our style quiz.", icon: Sparkles },
             { title: "AI Generation", desc: "Our Gemini-powered engine redesigns your exact room.", icon: Sofa },
             { title: "Shop the Look", desc: "Purchase the exact furniture seen in your design.", icon: ShoppingBag }
           ].map((f, i) => (
             <div key={i} className="bg-card p-8 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow group">
               <div className="w-12 h-12 bg-curalina-50 text-curalina-600 rounded-xl flex items-center justify-center mb-6 group-hover:bg-curalina-500 group-hover:text-white transition-colors">
                 <f.icon className="w-6 h-6" />
               </div>
               <h3 className="text-xl font-semibold text-slate-900 mb-3">{f.title}</h3>
               <p className="text-slate-500 leading-relaxed">{f.desc}</p>
             </div>
           ))}
        </div>
      </div>
    </div>
  );

  const renderLoading = () => (
    <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 text-center px-4">
      {designStatus === 'analyzing_room' && (
        <>
           <div className="w-16 h-16 border-4 border-curalina-200 border-t-curalina-600 rounded-full animate-spin mb-6"></div>
           <h2 className="text-2xl font-bold text-slate-900">Analyzing your space...</h2>
           <p className="text-slate-500 mt-2">Mapping dimensions, windows, and lighting.</p>
        </>
      )}
      {designStatus === 'generating' && (
        <>
           <div className="w-16 h-16 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mb-6"></div>
           <h2 className="text-2xl font-bold text-slate-900">Generating Design...</h2>
           <p className="text-slate-500 mt-2">Compositing products and rendering high-fidelity preview.</p>
        </>
      )}
      {designStatus === 'failed' && (
        <>
           <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center text-red-500 mb-6"><Trash2 className="w-8 h-8"/></div>
           <h2 className="text-2xl font-bold text-slate-900">Generation Failed</h2>
           <p className="text-slate-500 mt-2">We couldn't process your request. Please try again.</p>
        </>
      )}
    </div>
  );

  const renderResults = () => (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-64px)] overflow-hidden bg-slate-50 animate-in fade-in">
       <div className="lg:w-2/3 h-full relative bg-slate-900 flex items-center justify-center">
          {generatedDesign?.imageUrl && <img src={generatedDesign.imageUrl} className="max-w-full max-h-full object-contain shadow-2xl" alt="Design" />}
          <div className="absolute bottom-6 left-6 bg-black/50 backdrop-blur-md text-white px-4 py-2 rounded-lg text-sm border border-white/10">
            Generated with Gemini 2.5 Flash
          </div>
       </div>
       <div className="lg:w-1/3 h-full overflow-y-auto bg-card p-6 border-l border-slate-200 shadow-xl z-10">
          <div className="mb-6">
            <h2 className="text-xl font-bold text-slate-900">Shop the Look</h2>
            <p className="text-sm text-slate-500 mt-1">Products used in this design</p>
          </div>
          <div className="space-y-4">
            {generatedDesign?.products.map(p => (
              <ProductCard key={p.id} product={p} onAddToCart={addToCart} isCompact={true} />
            ))}
          </div>
          <button 
            onClick={() => setView('quiz')}
            className="w-full mt-8 py-3 border border-slate-300 rounded-xl text-slate-600 font-medium hover:bg-slate-100 transition-colors"
          >
            Regenerate Design
          </button>
       </div>
    </div>
  );

  const renderCart = () => (
    <div className="max-w-7xl mx-auto px-4 py-12 animate-in slide-in-from-right duration-300">
       <h2 className="text-3xl font-bold mb-8 text-slate-900">Shopping Cart</h2>
       {cart.length === 0 ? (
         <div className="text-center py-20 text-slate-500 bg-card rounded-xl border border-slate-200">
            <ShoppingBag className="w-12 h-12 mx-auto mb-4 text-slate-300"/>
            <p className="text-lg font-medium">Your cart is empty</p>
            <button onClick={() => setView('marketplace')} className="mt-4 text-curalina-600 hover:underline">Start Shopping</button>
         </div>
       ) : (
         <div className="grid md:grid-cols-3 gap-8">
           <div className="md:col-span-2 space-y-4">
             {cart.map(item => (
               <div key={item.id} className="flex gap-4 p-4 bg-card border border-slate-200 rounded-xl shadow-sm">
                  <div className="w-24 h-24 rounded-lg bg-slate-100 overflow-hidden shrink-0">
                    <img src={item.imageUrl} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 flex flex-col justify-between">
                     <div className="flex justify-between font-bold text-slate-900">
                        <h3 className="text-lg">{item.name}</h3>
                        <span>${(item.salePrice || item.price) * item.quantity}</span>
                     </div>
                     <p className="text-sm text-slate-500">{item.category} • {item.sku}</p>
                     <div className="flex justify-between items-end">
                        <div className="text-xs bg-slate-100 px-3 py-1 rounded-full border border-slate-200 font-medium">Qty: {item.quantity}</div>
                        <button onClick={() => removeFromCart(item.id)} className="text-red-500 text-sm flex items-center gap-1 hover:text-red-600 transition-colors p-1 rounded hover:bg-red-50">
                          <Trash2 className="w-4 h-4"/> Remove
                        </button>
                     </div>
                  </div>
               </div>
             ))}
           </div>
           <div className="md:col-span-1">
              <div className="bg-card p-6 rounded-xl border border-slate-200 shadow-sm sticky top-24">
                 <h3 className="font-bold text-lg mb-4 text-slate-900">Order Summary</h3>
                 <div className="space-y-3 text-sm mb-6 border-b border-slate-200 pb-6">
                    <div className="flex justify-between text-slate-600"><span>Subtotal</span><span>${getCartTotal()}</span></div>
                    <div className="flex justify-between text-slate-600"><span>Tax (8%)</span><span>${Math.round(getCartTotal() * 0.08)}</span></div>
                    <div className="flex justify-between text-slate-600"><span>Shipping</span><span className="text-green-600">Free</span></div>
                 </div>
                 <div className="flex justify-between font-bold text-xl mb-6 text-slate-900"><span>Total</span><span>${Math.round(getCartTotal() * 1.08)}</span></div>
                 <button onClick={handleCheckout} className="w-full bg-slate-900 text-white py-3.5 rounded-xl font-bold hover:bg-slate-800 transition-colors shadow-lg transform hover:-translate-y-0.5">Proceed to Checkout</button>
              </div>
           </div>
         </div>
       )}
    </div>
  );

  // --- Execution ---
  
  if (!hasApiKey) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100 p-4">
        <div className="bg-card w-full max-w-md p-8 rounded-2xl shadow-xl border border-slate-200 text-center animate-in zoom-in duration-300">
          <div className="w-16 h-16 bg-curalina-500 rounded-2xl flex items-center justify-center mx-auto mb-6 text-white shadow-lg">
             <Lock className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-3">Authentication Required</h2>
          <p className="text-slate-600 mb-8">
            To use Curalina's advanced AI design features (Gemini Flash & Vision), you must connect your Google API Key.
          </p>
          <button 
            onClick={handleSelectKey}
            className="w-full bg-slate-900 text-white py-4 rounded-xl font-bold hover:bg-slate-800 transition-all shadow-lg flex items-center justify-center gap-2"
          >
            Connect Google API Key
          </button>
        </div>
      </div>
    );
  }

  if (!dbLoaded) return null;

  if (view === 'admin') {
    if (!isAdminAuthenticated) {
      return <AdminLogin onLogin={handleAdminLogin} onCancel={() => setView('landing')} />;
    }
    return (
      <AdminDashboard 
        products={products} 
        users={users}
        orders={orders}
        suppliers={suppliers}
        renders={renders}
        onAddProduct={handleAddProduct} 
        onBulkAddProducts={handleBulkAddProducts} 
        onBulkUpsertProducts={handleBulkUpsertProducts}
        onAddUser={handleAddUser}
        onLogout={handleAdminLogout} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      {renderHeader()}
      <main>
        {view === 'landing' && renderLanding()}
        {view === 'quiz' && <DesignQuiz onComplete={handleQuizComplete} />}
        {view === 'loading' && renderLoading()}
        {view === 'results' && renderResults()}
        {view === 'cart' && renderCart()}
        {view === 'marketplace' && (
           <div className="max-w-7xl mx-auto px-4 py-8">
             <h2 className="text-2xl font-bold text-slate-900 mb-6">Marketplace</h2>
             <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
               {products.map(p => <ProductCard key={p.id} product={p} onAddToCart={addToCart} />)}
             </div>
           </div>
        )}
      </main>
    </div>
  );
};

export default App;
