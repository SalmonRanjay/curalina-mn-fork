
import express from 'express';
import cors from 'cors';
import { db } from './db';
import { products, users, orders, renders, suppliers } from './db/schema';
import { eq, sql } from 'drizzle-orm';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3001; 

console.log('-------------------------------------------');
console.log(`🚀 STARTING SERVER ON PORT ${PORT}`);
console.log('-------------------------------------------');

app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '200mb' }) as any);

// Request Logger
app.use((req, res, next) => {
  console.log(`[API Request] ${req.method} ${req.url}`);
  next();
});

// Health Check
app.get('/api/health', (req, res) => {
  res.type('text/plain').send('OK');
});

// Debug Status
app.get('/api/debug/status', async (req, res) => {
    try {
        const count = await db.execute(sql`SELECT count(*) from products`);
        res.json({ status: 'connected', count: count.rows[0].count });
    } catch (e: any) {
        res.status(500).json({ status: 'error', message: e.message });
    }
});

// --- PRODUCTS ---
app.get('/api/products', async (req, res) => {
  try {
    const result = await db.select().from(products);
    const formatted = result.map(p => ({
        ...p,
        dimensions: { 
            h: Number(p.height), 
            w: Number(p.width), 
            d: Number(p.depth), 
            unit: 'inches' 
        },
        price: Number(p.price),
        salePrice: p.salePrice ? Number(p.salePrice) : undefined,
        stock: p.stock,
        tradePrice: p.tradePrice ? Number(p.tradePrice) : undefined,
        weight: p.weight ? Number(p.weight) : undefined
    }));
    res.json(formatted);
  } catch (error) {
    console.error("Fetch Products Error:", error);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

app.post('/api/products', async (req, res) => {
  try {
    const item = req.body;
    const result = await db.insert(products).values({
        ...item,
        price: item.price?.toString(),
        salePrice: item.salePrice?.toString(),
        tradePrice: item.tradePrice?.toString(),
        stock: item.stock ? Number(item.stock) : 0,
        width: item.dimensions?.w?.toString(),
        height: item.dimensions?.h?.toString(),
        depth: item.dimensions?.d?.toString(),
        armWidth: item.armWidth?.toString(),
        armDepth: item.armDepth?.toString(),
        seatWidth: item.seatWidth?.toString(),
        seatDepth: item.seatDepth?.toString(),
        volume: item.volume?.toString(),
        doorWidth: item.doorWidth?.toString(),
        doorThickness: item.doorThickness?.toString(),
        doorHeight: item.doorHeight?.toString(),
        legBaseDepth1: item.legBaseDepth1?.toString(),
        legBaseHeight1: item.legBaseHeight1?.toString(),
        legBaseWidth1: item.legBaseWidth1?.toString(),
        tabletopThickness: item.tabletopThickness?.toString(),
        weight: item.weight?.toString()
    }).returning();
    
    const formatted = {
        ...result[0],
        dimensions: {
            h: Number(result[0].height),
            w: Number(result[0].width),
            d: Number(result[0].depth),
            unit: 'inches'
        },
        price: Number(result[0].price),
        stock: result[0].stock
    };
    
    res.json(formatted);
  } catch (e) { 
      console.error("Add Product Error:", e);
      res.status(500).json({ error: 'Failed to add product' }); 
  }
});

app.post('/api/products/bulk', async (req, res) => {
  try {
    const items = req.body;
    if (!Array.isArray(items) || items.length === 0) return res.status(400).json({ error: 'Invalid data' });

    console.log(`[Server] Processing Bulk Upsert for ${items.length} items...`);

    const result = await db.insert(products)
      .values(items.map((item: any) => ({
        ...item,
        price: item.price?.toString(),
        stock: item.stock ? Number(item.stock) : 0,
        width: item.dimensions?.w?.toString(),
        height: item.dimensions?.h?.toString(),
        depth: item.dimensions?.d?.toString(),
        tradePrice: item.tradePrice?.toString(),
        weight: item.weight?.toString(),
        armWidth: item.armWidth?.toString(),
        armDepth: item.armDepth?.toString(),
        seatWidth: item.seatWidth?.toString(),
        seatDepth: item.seatDepth?.toString(),
        volume: item.volume?.toString(),
        doorWidth: item.doorWidth?.toString(),
        doorThickness: item.doorThickness?.toString(),
        doorHeight: item.doorHeight?.toString(),
        legBaseDepth1: item.legBaseDepth1?.toString(),
        legBaseHeight1: item.legBaseHeight1?.toString(),
        legBaseWidth1: item.legBaseWidth1?.toString(),
        tabletopThickness: item.tabletopThickness?.toString(),
      })))
      .onConflictDoUpdate({
        target: products.sku,
        set: {
          name: sql`excluded.name`,
          description: sql`excluded.description`,
          category: sql`excluded.category`,
          roomType: sql`excluded.room_type`,
          price: sql`excluded.price`,
          tradePrice: sql`excluded.trade_price`,
          stock: sql`excluded.stock`,
          styleTags: sql`excluded.style_tags`,
          keyFeatures: sql`excluded.key_features`,
          colors: sql`excluded.colors`,
          materials: sql`excluded.materials`,
          imageUrl: sql`excluded.image_url`,
          images: sql`excluded.images`,
          updatedAt: new Date(),
          height: sql`excluded.height`,
          width: sql`excluded.width`,
          depth: sql`excluded.depth`,
          weight: sql`excluded.weight`
        }
      })
      .returning();

    console.log(`[Server] Successfully upserted ${result.length} items.`);
    res.json(result);
  } catch (error) {
    console.error("Bulk Import Error:", error);
    res.status(500).json({ error: 'Bulk import failed' });
  }
});

// --- USERS, ORDERS, SUPPLIERS, RENDERS ---
app.get('/api/users', async (req, res) => {
    try { res.json(await db.select().from(users)); } 
    catch (e) { res.status(500).json({ error: 'Fetch failed' }); }
});
app.post('/api/users', async (req, res) => {
    try { res.json((await db.insert(users).values(req.body).returning())[0]); } 
    catch (e) { res.status(500).json({ error: 'Add failed' }); }
});

app.get('/api/orders', async (req, res) => {
    try { 
        const result = await db.select().from(orders);
        res.json(result.map(o => ({...o, total: Number(o.total)})));
    } catch (e) { res.status(500).json({ error: 'Fetch failed' }); }
});
app.post('/api/orders', async (req, res) => {
    try {
        const order = req.body;
        const result = await db.insert(orders).values({...order, total: order.total.toString()}).returning();
        res.json({...result[0], total: Number(result[0].total)});
    } catch (e) { res.status(500).json({ error: 'Add failed' }); }
});

app.get('/api/suppliers', async (req, res) => {
    try { res.json(await db.select().from(suppliers)); } 
    catch (e) { res.status(500).json({ error: 'Fetch failed' }); }
});

app.get('/api/renders', async (req, res) => {
    try { res.json(await db.select().from(renders)); } 
    catch (e) { res.status(500).json({ error: 'Fetch failed' }); }
});
app.post('/api/renders', async (req, res) => {
    try { res.json((await db.insert(renders).values(req.body).returning())[0]); } 
    catch (e) { res.status(500).json({ error: 'Add failed' }); }
});

// Start Server - Bind to all interfaces for Replit
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n✅ SERVER IS LISTENING ON http://0.0.0.0:${PORT}\n`);
});
