
import { pgTable, text, integer, decimal, boolean, jsonb, uuid, timestamp } from 'drizzle-orm/pg-core';

export const products = pgTable('products', {
  id: uuid('id').defaultRandom().primaryKey(),
  
  // ✅ Required Fields (12)
  name: text('name').notNull(),                 // Product Name
  description: text('description').notNull(),   // Overview
  supplier: text('supplier').notNull(),         // Supplier
  sku: text('sku').unique().notNull(),          // SKU
  category: text('category').notNull(),         // Furniture Category
  roomType: text('room_type').notNull(),        // Room Type
  styleTags: jsonb('style_tags').$type<string[]>().default([]), // Design Style
  keyFeatures: jsonb('key_features').$type<string[]>().default([]), // Key Features
  storageSolutions: text('storage_solutions'),  // Storage Solutions
  colors: jsonb('colors').$type<string[]>().default([]), // Colour
  materials: jsonb('materials').$type<string[]>().default([]), // Product Materials
  stock: integer('stock').default(0),           // Inventory

  // 🟨 Optional Fields (26)
  tradePrice: decimal('trade_price', { precision: 10, scale: 2 }), // Trade Price
  price: decimal('price', { precision: 10, scale: 2 }).notNull(),  // Retail Price
  
  // Dimensions
  height: decimal('height', { precision: 10, scale: 2 }), // Dimensions (Height)
  width: decimal('width', { precision: 10, scale: 2 }),   // Dimensions (Width)
  depth: decimal('depth', { precision: 10, scale: 2 }),   // Dimensions (Depth)
  
  armWidth: decimal('arm_width', { precision: 10, scale: 2 }),   // Arm Width
  armDepth: decimal('arm_depth', { precision: 10, scale: 2 }),   // Arm Depth
  seatWidth: decimal('seat_width', { precision: 10, scale: 2 }), // Seat Width
  seatDepth: decimal('seat_depth', { precision: 10, scale: 2 }), // Seat Depth
  volume: decimal('volume', { precision: 10, scale: 2 }),        // Volume
  
  doorWidth: decimal('door_width', { precision: 10, scale: 2 }),     // Door Width
  doorThickness: decimal('door_thickness', { precision: 10, scale: 2 }), // Door Thickness
  doorHeight: decimal('door_height', { precision: 10, scale: 2 }),   // Door Height
  
  legBaseDepth1: decimal('leg_base_depth_1', { precision: 10, scale: 2 }), // Leg/Base Depth 1
  legBaseHeight1: decimal('leg_base_height_1', { precision: 10, scale: 2 }), // Height 1
  legBaseWidth1: decimal('leg_base_width_1', { precision: 10, scale: 2 }), // Width 1
  
  tabletopThickness: decimal('tabletop_thickness', { precision: 10, scale: 2 }), // Tabletop Thickness
  shapeType: text('shape_type'), // Shape Type
  
  seatingCapacity: text('seating_capacity'), // Seating
  assembly: text('assembly'),                // Assembly
  leadTime: text('lead_time'),               // Lead Time
  deliveryOptions: text('delivery_options'), // Delivery Options
  deliveryLocation: text('delivery_location'), // Location
  deliveryPolicy: text('delivery_policy'),   // Policy
  tags: jsonb('tags').$type<string[]>().default([]), // Tags
  weight: decimal('weight', { precision: 10, scale: 2 }), // Weight (lbs)
  
  // System Fields
  salePrice: decimal('sale_price', { precision: 10, scale: 2 }),
  imageUrl: text('image_url'),
  images: jsonb('images').$type<string[]>().default([]),
  
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const users = pgTable('users', {
  id: uuid('id').defaultRandom().primaryKey(),
  name: text('name').notNull(),
  email: text('email').unique().notNull(),
  role: text('role').default('viewer'),
  status: text('status').default('active'),
  lastActive: timestamp('last_active').defaultNow(),
});

export const orders = pgTable('orders', {
  id: text('id').primaryKey(), // Using custom string IDs like ORD-123
  customerName: text('customer_name').notNull(),
  email: text('email').notNull(),
  date: timestamp('date').defaultNow(),
  total: decimal('total', { precision: 10, scale: 2 }).notNull(),
  status: text('status').default('Pending'),
  itemsCount: integer('items_count').default(0),
});

export const renders = pgTable('renders', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: text('user_id'),
  prompt: text('prompt'),
  imageUrl: text('image_url'),
  roomType: text('room_type'),
  status: text('status'),
  date: timestamp('date').defaultNow(),
});

export const suppliers = pgTable('suppliers', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  contactEmail: text('contact_email'),
  status: text('status').default('Active'),
  productsCount: integer('products_count').default(0),
  rating: decimal('rating', { precision: 2, scale: 1 }).default('5.0'),
});
