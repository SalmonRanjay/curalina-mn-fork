import { drizzle } from 'drizzle-orm/node-postgres';
import { Client } from 'pg';
import * as schema from './schema';
import dotenv from 'dotenv';

dotenv.config();

// Default to a dummy string if not set to prevent crash during build, but functionality will fail at runtime if missing.
const connectionString = process.env.DATABASE_URL || "postgres://user:pass@localhost:5432/db";

const client = new Client({
  connectionString,
});

const connect = async () => {
  try {
    if (process.env.DATABASE_URL) {
        await client.connect();
        console.log("Connected to PostgreSQL");
    } else {
        console.warn("DATABASE_URL not found in environment. Server will start but DB calls will fail.");
    }
  } catch (err) {
    console.error("Failed to connect to DB:", err);
  }
};
connect();

export const db = drizzle(client, { schema });