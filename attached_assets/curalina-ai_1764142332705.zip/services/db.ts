
import { Product, User, Order, Supplier, RenderLog } from '../types';
import { 
  INITIAL_CATALOG, 
  INITIAL_USERS, 
  INITIAL_ORDERS, 
  INITIAL_SUPPLIERS, 
  INITIAL_RENDERS 
} from './initialData';

const KEYS = {
  PRODUCTS: 'curalina_products',
  USERS: 'curalina_users',
  ORDERS: 'curalina_orders',
  SUPPLIERS: 'curalina_suppliers',
  RENDERS: 'curalina_renders'
};

const API_BASE = '/api';
let isConnected = false;

// --- Local Storage Helpers ---
const loadLocal = <T>(key: string, defaultData: T[]): T[] => {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultData;
  } catch (e) {
    return defaultData;
  }
};

const saveLocal = <T>(key: string, data: T[]) => {
  try {
    const json = JSON.stringify(data);
    localStorage.setItem(key, json);
  } catch (e: any) {
    if (
        e.name === 'QuotaExceededError' || 
        e.toString().includes('Invalid string length') || 
        e.code === 22
    ) {
       console.warn(`LocalStorage limit reached for ${key}. Attempting to save without heavy images.`);
       try {
         const strippedData = data.map((item: any) => {
            if (typeof item !== 'object' || item === null) return item;
            const newItem = { ...item };
            if (typeof newItem.imageUrl === 'string' && newItem.imageUrl.startsWith('data:image')) {
                newItem.imageUrl = 'https://placehold.co/600x400?text=Image+Too+Large+For+Local+Storage';
            }
            if (Array.isArray(newItem.images)) {
                newItem.images = newItem.images.map((img: string) => 
                    typeof img === 'string' && img.startsWith('data:image') ? '' : img
                ).filter(Boolean);
            }
            return newItem;
         });
         localStorage.setItem(key, JSON.stringify(strippedData));
       } catch (retryError) {
         console.error(`Failed to save ${key} locally.`, retryError);
       }
    } else {
       console.error(`Failed to save ${key} locally`, e);
    }
  }
};

// --- Hybrid DB Service ---
export const db = {
  status: () => isConnected ? 'Connected (Server)' : 'Connected (Local)',

  init: async () => {
    let retries = 20; // Try for 20 seconds
    console.log("[DB] Initializing connection sequence...");
    
    while (retries > 0) {
        try {
            // We use specific headers to try and bypass simple cache or HTML responses
            const res = await fetch(`${API_BASE}/health`, {
                headers: { 'Cache-Control': 'no-cache' }
            });
            
            if (res.ok) {
                const contentType = res.headers.get("content-type");
                const text = await res.text();
                
                // Validate it's actually the API responding, not the frontend HTML 404 page
                if ((contentType && contentType.includes("application/json")) || text.trim() === 'OK') {
                    isConnected = true;
                    console.log("✅ Backend Connection Established");
                    return true;
                } else {
                    console.warn(`[DB] Backend reachable but returned unexpected response type (likely HTML proxy fallback): "${text.substring(0, 50)}..."`);
                }
            } else {
                 console.warn(`[DB] Health check failed with status: ${res.status}`);
            }
        } catch (e: any) {
            if (retries % 5 === 0) {
              console.warn(`[DB] Connection attempt failed (${e.message}). Retries left: ${retries}. Ensure 'npm run dev' is running in server folder.`);
            }
        }
        retries--;
        await new Promise(r => setTimeout(r, 1000)); // Wait 1s
    }

    isConnected = false;
    console.error("❌ Could not connect to backend. Falling back to LocalStorage.");

    // Seed Local Data if missing (for fallback mode)
    if (!isConnected) {
        const currentProducts = loadLocal<Product>(KEYS.PRODUCTS, []);
        if (currentProducts.length < 10) {
           saveLocal(KEYS.PRODUCTS, INITIAL_CATALOG);
        }
        if (!localStorage.getItem(KEYS.USERS)) saveLocal(KEYS.USERS, INITIAL_USERS);
        if (!localStorage.getItem(KEYS.ORDERS)) saveLocal(KEYS.ORDERS, INITIAL_ORDERS);
        if (!localStorage.getItem(KEYS.SUPPLIERS)) saveLocal(KEYS.SUPPLIERS, INITIAL_SUPPLIERS);
        if (!localStorage.getItem(KEYS.RENDERS)) saveLocal(KEYS.RENDERS, INITIAL_RENDERS);
    }
    return true;
  },

  checkConnection: async () => {
      try {
          const res = await fetch(`${API_BASE}/health`);
          const text = await res.text();
          if (res.ok && text.trim() === 'OK') {
              isConnected = true;
              return true;
          }
      } catch (e) { console.error("Reconnection failed", e); }
      return false;
  },

  products: {
    getAll: async (): Promise<Product[]> => {
        if (isConnected) {
            const res = await fetch(`${API_BASE}/products`);
            return await res.json();
        }
        return loadLocal(KEYS.PRODUCTS, INITIAL_CATALOG);
    },
    add: async (product: Product) => {
        if (isConnected) {
            await fetch(`${API_BASE}/products`, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(product)
            });
            const res = await fetch(`${API_BASE}/products`);
            return await res.json();
        } else {
            const items = loadLocal<Product>(KEYS.PRODUCTS, INITIAL_CATALOG);
            const newItems = [product, ...items];
            saveLocal(KEYS.PRODUCTS, newItems);
            return newItems;
        }
    },
    bulkAdd: async (products: Product[]) => {
        if (isConnected) {
            const res = await fetch(`${API_BASE}/products/bulk`, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(products)
            });
            return await res.json();
        } else {
            const items = loadLocal<Product>(KEYS.PRODUCTS, INITIAL_CATALOG);
            const newItems = [...products, ...items];
            saveLocal(KEYS.PRODUCTS, newItems);
            return newItems;
        }
    },
    bulkUpsert: async (products: Product[]) => {
        if (isConnected) {
            const res = await fetch(`${API_BASE}/products/bulk`, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(products)
            });
            return await res.json();
        } else {
            let items = loadLocal<Product>(KEYS.PRODUCTS, INITIAL_CATALOG);
            const productMap = new Map(items.map(p => [p.id, p]));
            const skuMap = new Map(items.filter(p => p.sku).map(p => [p.sku, p]));

            products.forEach(p => {
                const existing = productMap.get(p.id) || skuMap.get(p.sku);
                if (existing) {
                    const merged = { ...existing, ...p, id: existing.id };
                    productMap.set(existing.id, merged);
                } else {
                    productMap.set(p.id, p);
                }
            });
            const newItems = Array.from(productMap.values());
            saveLocal(KEYS.PRODUCTS, newItems);
            return newItems;
        }
    }
  },

  users: {
    getAll: async (): Promise<User[]> => {
        if (isConnected) {
            const res = await fetch(`${API_BASE}/users`);
            return await res.json();
        }
        return loadLocal(KEYS.USERS, INITIAL_USERS);
    },
    add: async (user: User) => {
        if (isConnected) {
            await fetch(`${API_BASE}/users`, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(user)
            });
            const res = await fetch(`${API_BASE}/users`);
            return await res.json();
        } else {
            const items = loadLocal<User>(KEYS.USERS, INITIAL_USERS);
            const newItems = [user, ...items];
            saveLocal(KEYS.USERS, newItems);
            return newItems;
        }
    }
  },

  orders: {
    getAll: async (): Promise<Order[]> => {
        if (isConnected) {
            const res = await fetch(`${API_BASE}/orders`);
            return await res.json();
        }
        return loadLocal(KEYS.ORDERS, INITIAL_ORDERS);
    },
    add: async (order: Order) => {
        if (isConnected) {
             await fetch(`${API_BASE}/orders`, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(order)
            });
            const res = await fetch(`${API_BASE}/orders`);
            return await res.json();
        } else {
            const items = loadLocal<Order>(KEYS.ORDERS, INITIAL_ORDERS);
            const newItems = [order, ...items];
            saveLocal(KEYS.ORDERS, newItems);
            return newItems;
        }
    }
  },

  suppliers: {
    getAll: async (): Promise<Supplier[]> => {
        if (isConnected) {
            const res = await fetch(`${API_BASE}/suppliers`);
            return await res.json();
        }
        return loadLocal(KEYS.SUPPLIERS, INITIAL_SUPPLIERS);
    }
  },

  renders: {
    getAll: async (): Promise<RenderLog[]> => {
        if (isConnected) {
            const res = await fetch(`${API_BASE}/renders`);
            return await res.json();
        }
        return loadLocal(KEYS.RENDERS, INITIAL_RENDERS);
    },
    add: async (log: RenderLog) => {
        if (isConnected) {
             await fetch(`${API_BASE}/renders`, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(log)
            });
            const res = await fetch(`${API_BASE}/renders`);
            return await res.json();
        } else {
            const items = loadLocal<RenderLog>(KEYS.RENDERS, INITIAL_RENDERS);
            const newItems = [log, ...items];
            saveLocal(KEYS.RENDERS, newItems);
            return newItems;
        }
    }
  },

  clear: async () => {
    localStorage.clear();
    window.location.reload();
  }
};
