
import { Product, QuizState, DesignStyle } from '../types';

// Define essential categories per room type to ensure a balanced design
const ESSENTIAL_CATEGORIES: Record<string, string[]> = {
  "Living Room": ["Seating", "Tables", "Rugs", "Lighting"],
  "Bedroom": ["Seating", "Storage", "Lighting", "Rugs"],
  "Dining Room": ["Tables", "Seating", "Storage", "Decor"],
  "Home Office": ["Tables", "Seating", "Storage", "Lighting"],
  "Entryway": ["Tables", "Decor", "Storage", "Rugs"],
  "Nursery": ["Seating", "Storage", "Decor", "Rugs"]
};

const CATEGORY_ALIASES: Record<string, string[]> = {
  "Seating": ["Seating", "Sofa", "Chair", "Armchair", "Sectional"],
  "Tables": ["Tables", "Table", "Desk", "Console", "Nightstand"],
  "Storage": ["Storage", "Cabinet", "Shelving", "Dresser", "Wardrobe"],
  "Lighting": ["Lighting", "Lamp", "Light"],
  "Rugs": ["Rugs", "Rug", "Textile"],
  "Decor": ["Decor", "Art", "Mirror", "Accessory"]
};

/**
 * Helper to check if a product matches a generic category bucket
 */
const isInCategory = (productCategory: string, targetBucket: string): boolean => {
  const aliases = CATEGORY_ALIASES[targetBucket] || [targetBucket];
  return aliases.some(a => productCategory.includes(a));
};

/**
 * Intelligent Product Selection Algorithm
 * 1. Filter by Room Type (Strict)
 * 2. Score by Style Match (High Weight)
 * 3. Score by Vibe/Color (Medium Weight)
 * 4. Select top item per Essential Category to create a cohesive room set
 */
export const selectBestFitProducts = (allProducts: Product[], quizState: QuizState): Product[] => {
  if (!allProducts || allProducts.length === 0) return [];

  // 1. Strict Filter: Room Type
  // If product has specific roomTypes defined, it must match. If 'Any' or empty, it passes.
  const roomCandidates = allProducts.filter(p => {
    if (!p.roomType || p.roomType === 'Any') return true;
    // Split CSV or array if needed, usually it's a single string in this DB schema
    return p.roomType.includes(quizState.roomType || 'Living Room');
  });

  // 2. Scoring System
  const scoredCandidates = roomCandidates.map(p => {
    let score = 0;

    // Style Match (Max 50 points)
    const productStyles = p.styleTags || [];
    const userStyles = quizState.styles || [];
    
    const exactMatches = productStyles.filter(tag => userStyles.includes(tag as DesignStyle)).length;
    if (exactMatches > 0) {
      score += 50; // Strong match
    } else {
      // Fuzzy match style names
      const hasPartialMatch = userStyles.some(us => productStyles.some(ps => ps.includes(us) || us.includes(ps)));
      if (hasPartialMatch) score += 20;
    }

    // Vibe/Color Match (Max 30 points)
    if (quizState.vibeAnalysis && p.colors) {
      const vibeColors = quizState.vibeAnalysis.colorPalette.map(c => c.toLowerCase());
      const productColors = p.colors.map(c => c.toLowerCase());
      const colorMatch = productColors.some(pc => vibeColors.some(vc => vc.includes(pc) || pc.includes(vc)));
      if (colorMatch) score += 30;
    }

    // Feature Match (Max 20 points)
    // e.g., if user wants "Storage", prioritize storage items
    if (quizState.features && p.keyFeatures) {
      const featureMatch = quizState.features.some(f => 
        p.keyFeatures.some(pf => pf.toLowerCase().includes(f.toLowerCase())) ||
        p.category.toLowerCase().includes(f.toLowerCase())
      );
      if (featureMatch) score += 20;
    }

    return { product: p, score };
  });

  // Sort by score descending
  scoredCandidates.sort((a, b) => b.score - a.score);

  // 3. Category Balancing
  // We want to select ~4-5 items that form a complete room, not 5 sofas.
  const roomType = quizState.roomType || "Living Room";
  const requiredCategories = ESSENTIAL_CATEGORIES[roomType] || ESSENTIAL_CATEGORIES["Living Room"];
  
  const selectedProducts: Product[] = [];
  const selectedIds = new Set<string>();

  // A. First, fill essential categories with the highest scoring items
  for (const categoryBucket of requiredCategories) {
    const bestInBucket = scoredCandidates.find(item => 
      !selectedIds.has(item.product.id) && 
      isInCategory(item.product.category, categoryBucket)
    );

    if (bestInBucket) {
      selectedProducts.push(bestInBucket.product);
      selectedIds.add(bestInBucket.product.id);
    }
  }

  // B. Fill remaining slots (up to 5 total) with next highest scoring items (Decor/Accents)
  // allowing duplicates of categories like 'Seating' (e.g. Sofa + Armchair) if they are different products
  let fillerIndex = 0;
  while (selectedProducts.length < 5 && fillerIndex < scoredCandidates.length) {
    const candidate = scoredCandidates[fillerIndex];
    if (!selectedIds.has(candidate.product.id)) {
       selectedProducts.push(candidate.product);
       selectedIds.add(candidate.product.id);
    }
    fillerIndex++;
  }

  return selectedProducts;
};
