
import { GoogleGenAI, Type } from "@google/genai";
import { ParsedRoomData, VibeAnalysis, Product, QuizState } from "../types";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key is missing.");
  }
  return new GoogleGenAI({ apiKey });
};

/**
 * Helper: Convert Image URL to Base64 for API
 * Browsers block fetch to external URLs (CORS) unless configured. 
 * We attempt to fetch; if it fails, we return null.
 */
const urlToBase64 = async (url: string): Promise<string | null> => {
  try {
    // If it's already base64, return bare data
    if (url.startsWith('data:')) {
       return url.split(',')[1];
    }

    const response = await fetch(url);
    const blob = await response.blob();
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        resolve(result.split(',')[1]); // return clean base64
      };
      reader.readAsDataURL(blob);
    });
  } catch (e) {
    console.warn("Could not convert product image to base64 (likely CORS). Sending text description only.", url);
    return null;
  }
};

/**
 * Step 1: Analyze Vibe Images to extract preferences
 */
export const analyzeVibeImages = async (base64Images: string[]): Promise<VibeAnalysis> => {
  const ai = getClient();
  
  const parts: any[] = [
    { text: `You are an expert interior designer. Analyze these inspiration images to understand the user's visual preferences. 
    Extract the following structured data:
    1. Color Palette (5-8 dominant colors with names)
    2. Materials (visible materials like "oak", "brass")
    3. Textures (surface finishes)
    4. Overall Vibe (2-3 sentences capturing the aesthetic)
    Return JSON.` }
  ];

  base64Images.forEach(img => {
    const data = img.split(',')[1] || img;
    parts.push({
      inlineData: {
        mimeType: 'image/jpeg',
        data: data
      }
    });
  });

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: { parts },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            colorPalette: { type: Type.ARRAY, items: { type: Type.STRING } },
            materials: { type: Type.ARRAY, items: { type: Type.STRING } },
            textures: { type: Type.ARRAY, items: { type: Type.STRING } },
            overallVibe: { type: Type.STRING }
          },
          required: ["colorPalette", "materials", "overallVibe"]
        }
      }
    });

    if (!response.text) throw new Error("No response from Vibe Analysis");
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Vibe analysis failed:", error);
    return {
      colorPalette: ["Neutral", "Beige"],
      materials: ["Wood", "Fabric"],
      textures: ["Smooth"],
      overallVibe: "A cozy and modern space."
    };
  }
};

/**
 * Step 2: Analyze Room Image for Structure Preservation
 */
export const analyzeRoomImage = async (base64Image: string): Promise<string> => {
  const ai = getClient();
  const data = base64Image.split(',')[1] || base64Image;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          { text: `Analyze this room photo for a redesign. Describe the ARCHITECTURAL STRUCTURE that must be preserved.
          Include:
          - Dimensions/Shape estimate
          - Window locations and sizes
          - Door locations
          - Ceiling features (height, beams, molding)
          - Flooring type
          - Lighting sources
          Do NOT describe the furniture as we will replace it. Focus on the empty shell.` },
          { inlineData: { mimeType: 'image/jpeg', data } }
        ]
      }
    });
    return response.text || "Standard room structure.";
  } catch (e) {
    console.error("Room analysis failed", e);
    return "Standard rectangular room with average ceiling height.";
  }
};

/**
 * Step 3: NLP Room Parsing
 */
export const parseRoomDescription = async (text: string): Promise<ParsedRoomData> => {
  const ai = getClient();
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Extract room dimensions and features from: "${text}". If missing, estimate standard sizes (confidence low).`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            dimensions: {
              type: Type.OBJECT,
              properties: {
                width: { type: Type.NUMBER },
                length: { type: Type.NUMBER },
                height: { type: Type.NUMBER },
                unit: { type: Type.STRING, enum: ["feet", "meters", "inches"] },
                confidenceScore: { type: Type.NUMBER }
              },
              required: ["width", "length", "height", "unit", "confidenceScore"]
            },
            features: { type: Type.ARRAY, items: { type: Type.STRING } }
          }
        }
      }
    });
    const parsed = JSON.parse(response.text || "{}");
    return { dimensions: parsed.dimensions, features: parsed.features, originalText: text };
  } catch (error) {
    return {
      dimensions: { width: 12, length: 14, height: 9, unit: 'feet', confidenceScore: 0.5 },
      features: [],
      originalText: text
    };
  }
};

/**
 * Step 4: Generate Final Design Image (High Fidelity)
 * Uses Multimodal Inputs: Room Image (Structure) + Product Images (Objects)
 */
export const generateRoomRender = async (
  quizState: QuizState, 
  selectedProducts: Product[],
  structureDescription?: string
): Promise<{ imageUrl: string; prompt: string }> => {
  const ai = getClient();

  // 1. Prepare the Base Parts (Text Prompt)
  const parts: any[] = [];

  // 2. Prepare Text Context
  const vibeContext = quizState.vibeAnalysis ? 
    `Style Vibe: ${quizState.vibeAnalysis.overallVibe}. Colors: ${quizState.vibeAnalysis.colorPalette.join(', ')}.` : 
    `Style: ${quizState.styles.join(', ')}.`;

  let prompt = `Professional Interior Design Render. 8k Resolution. Photorealistic.
  Task: Redesign the room to look exactly like the user's vision using specific products.
  
  ${vibeContext}
  
  ARCHITECTURAL INSTRUCTIONS:
  ${structureDescription ? `PRESERVE EXACT ARCHITECTURE: ${structureDescription}` : `Room Type: ${quizState.roomType}. Create a realistic spatial layout.`}
  
  CRITICAL PRODUCT PLACEMENT INSTRUCTIONS:
  You are provided with reference images for specific furniture items. You MUST composite these exact items into the scene.
  Do not hallucinate generic furniture. Use the visual data provided.
  `;

  // 3. Process Room Image (The "Shell")
  if (quizState.roomImage) {
    const roomData = quizState.roomImage.split(',')[1] || quizState.roomImage;
    parts.push({
        inlineData: { mimeType: 'image/jpeg', data: roomData }
    });
    prompt += `\nREFERENCE IMAGE 1: The user's actual room. Keep walls, windows, floor, and perspective EXACTLY as seen in this image. Replace existing furniture.\n`;
  }

  // 4. Process Product Images (The "Contents")
  // We iterate through products, try to get their image data, and append them to the prompt parts
  let imgIndex = quizState.roomImage ? 2 : 1; // Start index for referencing
  
  for (const p of selectedProducts) {
    if (p.imageUrl) {
        const base64 = await urlToBase64(p.imageUrl);
        if (base64) {
            parts.push({
                inlineData: { mimeType: 'image/jpeg', data: base64 }
            });
            prompt += `\nREFERENCE IMAGE ${imgIndex}: [${p.category}] ${p.name}.
            ACTION: Place this exact item in the room. 
            Visual Details: ${p.visualDescription || p.description}.
            Dimensions: ${p.dimensions.w}x${p.dimensions.h}x${p.dimensions.d} inches.\n`;
            imgIndex++;
        } else {
            // Fallback to text if image load fails
            prompt += `\nPRODUCT TO INCLUDE: [${p.category}] ${p.name}. 
            Description: ${p.visualDescription || p.description}.\n`;
        }
    }
  }

  prompt += `\nCOMPOSITION RULES:
  - Harmonious arrangement matching the room's scale.
  - Correct lighting and shadows for the inserted products.
  - Maintain the user's selected color palette: ${quizState.palettes.join(', ')}.`;

  // Add the text prompt as the last part (or first, Gemini handles both, but keeping structure)
  parts.push({ text: prompt });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image', // Using image generation model
      contents: { parts }
    });

    let imageUrl = '';
    // Check for inline image data in response
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        imageUrl = `data:image/png;base64,${part.inlineData.data}`;
        break;
      }
    }

    if (!imageUrl) {
        throw new Error("No image generated by Gemini.");
    }

    return { imageUrl, prompt };

  } catch (error) {
    console.error("Image generation failed:", error);
    // Fallback Mock for safety
    return { 
      imageUrl: "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=1600", 
      prompt 
    };
  }
};

/**
 * Admin Feature: Analyze Product Image
 */
export const analyzeProductImage = async (base64Image: string): Promise<Partial<Product>> => {
  const ai = getClient();
  const data = base64Image.split(',')[1] || base64Image;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          { text: `Analyze this furniture product. Extract details for a catalog.` },
          { inlineData: { mimeType: 'image/jpeg', data } }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            visualDescription: { type: Type.STRING },
            materials: { type: Type.ARRAY, items: { type: Type.STRING } },
            colors: { type: Type.ARRAY, items: { type: Type.STRING } },
            styleTags: { type: Type.ARRAY, items: { type: Type.STRING } },
            description: { type: Type.STRING }
          }
        }
      }
    });

    if (!response.text) throw new Error("No response");
    return JSON.parse(response.text);
  } catch (error) {
    return {
      visualDescription: "Analysis failed.",
      materials: [],
      colors: [],
      styleTags: [],
      description: ""
    };
  }
};
