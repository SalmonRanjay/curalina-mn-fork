
import { Product, User, Order, Supplier, RenderLog } from '../types';

export const INITIAL_CATALOG: Product[] = [
  // --- SEATING ---
  {
    id: '1', sku: 'SOFA-001', name: 'Cloud Boucle Sofa', price: 1499, salePrice: 1299, category: 'Seating',
    supplier: 'Nordic Home Co.', roomType: 'Living Room', stock: 15,
    dimensions: { w: 84, d: 38, h: 32, unit: 'inches' }, materials: ['Boucle', 'Oak'], colors: ['Cream'],
    imageUrl: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=800&q=80',
    description: 'Luxurious curved sofa in cream boucle.', styleTags: ['Organic Modern', 'Contemporary Luxe'],
    visualDescription: 'Curved cream boucle sofa with low profile and rounded arms.',
    keyFeatures: ['Curved design', 'Soft texture'], storageSolutions: 'None',
    seatingCapacity: '3', weight: 120
  },
  {
    id: '2', sku: 'CHR-045', name: 'Mid-Century Leather Chair', price: 899, category: 'Seating',
    supplier: 'Artisan Weaves', roomType: 'Living Room', stock: 8,
    dimensions: { w: 30, d: 32, h: 34, unit: 'inches' }, materials: ['Leather', 'Walnut'], colors: ['Cognac'],
    imageUrl: 'https://images.unsplash.com/photo-1567538096630-e9948267ce7d?auto=format&fit=crop&w=800&q=80',
    description: 'Classic cognac leather armchair.', styleTags: ['Midcentury Scandi', 'Modern Farmhouse'],
    visualDescription: 'Cognac leather armchair with walnut wood frame and tapered legs.',
    keyFeatures: ['Genuine leather', 'Tapered legs'], storageSolutions: 'None',
    seatingCapacity: '1', weight: 45
  },
  {
    id: 'S-003', sku: 'SEC-003', name: 'Velvet Sectional Sofa', price: 2499, category: 'Seating',
    supplier: 'Nordic Home Co.', roomType: 'Living Room', stock: 5,
    dimensions: { w: 108, d: 84, h: 30, unit: 'inches' }, materials: ['Velvet', 'Metal'], colors: ['Navy Blue'],
    imageUrl: 'https://images.unsplash.com/photo-1550226891-ef816aed4a98?auto=format&fit=crop&w=800&q=80',
    description: 'Deep navy velvet L-shaped sectional.', styleTags: ['Contemporary Luxe', 'Dark & Moody'],
    visualDescription: 'Large L-shaped sectional sofa upholstered in deep navy velvet with gold metal legs.',
    keyFeatures: ['L-Shape', 'Gold Legs'], storageSolutions: 'None',
    seatingCapacity: '5', weight: 200
  },
  {
    id: 'S-004', sku: 'CHR-112', name: 'Linen Lounge Chair', price: 599, category: 'Seating',
    supplier: 'Artisan Weaves', roomType: 'Bedroom', stock: 12,
    dimensions: { w: 32, d: 34, h: 30, unit: 'inches' }, materials: ['Linen', 'Ash Wood'], colors: ['Beige'],
    imageUrl: 'https://images.unsplash.com/photo-1594026112284-02bb6f3352fe?auto=format&fit=crop&w=800&q=80',
    description: 'Relaxed linen armchair with wood frame.', styleTags: ['Organic Modern', 'Midcentury Scandi'],
    visualDescription: 'Beige linen upholstered armchair with light ash wood frame and armrests.',
    keyFeatures: ['Breathable fabric', 'Relaxed fit'], storageSolutions: 'None',
    seatingCapacity: '1', weight: 35
  },
  {
    id: 'S-005', sku: 'CHR-888', name: 'Sculptural White Chair', price: 749, category: 'Seating',
    supplier: 'Nordic Home Co.', roomType: 'Living Room', stock: 4,
    dimensions: { w: 28, d: 28, h: 30, unit: 'inches' }, materials: ['Sherpa', 'Wood'], colors: ['White'],
    imageUrl: 'https://images.unsplash.com/photo-1519947486511-46149fa0a254?auto=format&fit=crop&w=800&q=80',
    description: 'Avant-garde sculptural accent chair.', styleTags: ['Contemporary Luxe', 'Artful Eclectic'],
    visualDescription: 'Rounded, organic shape accent chair covered in white sherpa fabric.',
    keyFeatures: ['Statement piece', 'Sherpa texture'], storageSolutions: 'None',
    seatingCapacity: '1', weight: 40
  },
  {
    id: 'S-006', sku: 'OTT-001', name: 'Leather Ottoman', price: 349, category: 'Seating',
    supplier: 'Modern Metalworks', roomType: 'Living Room', stock: 20,
    dimensions: { w: 24, d: 24, h: 16, unit: 'inches' }, materials: ['Leather'], colors: ['Tan'],
    imageUrl: 'https://images.unsplash.com/photo-1589585814527-780d9e057893?auto=format&fit=crop&w=800&q=80',
    description: 'Square tanned leather pouf.', styleTags: ['Modern Farmhouse', 'Midcentury Scandi'],
    visualDescription: 'Square leather ottoman with stitched detailing in warm tan color.',
    keyFeatures: ['Versatile', 'Durable'], storageSolutions: 'None',
    seatingCapacity: '1', weight: 15
  },
  {
    id: 'S-007', sku: 'SOFA-099', name: 'Olive Green Sofa', price: 1799, category: 'Seating',
    supplier: 'Nordic Home Co.', roomType: 'Living Room', stock: 6,
    dimensions: { w: 88, d: 36, h: 32, unit: 'inches' }, materials: ['Velvet', 'Wood'], colors: ['Olive'],
    imageUrl: 'https://images.unsplash.com/photo-1552862750-746b8f6f7f25?auto=format&fit=crop&w=800&q=80',
    description: 'Modern sofa in rich olive velvet.', styleTags: ['Midcentury Scandi', 'Dark & Moody'],
    visualDescription: 'Three-seater tufted sofa in olive green velvet with dark wood tapered legs.',
    keyFeatures: ['Tufted seat', 'Rich color'], storageSolutions: 'None',
    seatingCapacity: '3', weight: 110
  },

  // --- TABLES ---
  {
    id: '3', sku: 'TBL-042', name: 'Travertine Coffee Table', price: 699, category: 'Tables',
    supplier: 'Modern Metalworks', roomType: 'Living Room', stock: 3,
    dimensions: { w: 48, d: 24, h: 16, unit: 'inches' }, materials: ['Travertine'], colors: ['Beige'],
    imageUrl: 'https://images.unsplash.com/photo-1633505299982-35323a63589b?auto=format&fit=crop&w=800&q=80',
    description: 'Sculptural stone coffee table.', styleTags: ['Organic Modern', 'Contemporary Luxe'],
    visualDescription: 'Rectangular travertine coffee table with cylindrical legs.',
    keyFeatures: ['Natural stone', 'Heavy duty'], storageSolutions: 'None',
    weight: 150
  },
  // --- STORAGE ---
  {
    id: 'ST-001', sku: 'CAB-001', name: 'Oak Sideboard', price: 1299, category: 'Storage',
    supplier: 'Nordic Home Co.', roomType: 'Dining Room', stock: 7,
    dimensions: { w: 72, d: 18, h: 30, unit: 'inches' }, materials: ['Oak'], colors: ['Light Wood'],
    imageUrl: 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=800&q=80',
    description: 'Spacious storage credenza.', styleTags: ['Organic Modern', 'Midcentury Scandi'],
    visualDescription: 'Light oak sideboard with sliding slat doors.',
    keyFeatures: ['Sliding doors', 'Ample storage'], storageSolutions: 'Shelves'
  }
];

export const INITIAL_USERS: User[] = [
  { id: '1', name: 'Admin User', email: 'admin@curalina.ai', role: 'admin', status: 'active', lastActive: 'Just now' },
  { id: '2', name: 'Sarah Designer', email: 'sarah@design.co', role: 'editor', status: 'active', lastActive: '2 hours ago' },
  { id: '3', name: 'Mike Vendor', email: 'mike@furniture.com', role: 'viewer', status: 'inactive', lastActive: '5 days ago' },
];

export const INITIAL_ORDERS: Order[] = [
  { id: 'ORD-7829', customerName: 'Alice Smith', email: 'alice@example.com', date: '2023-10-24', total: 2499.00, status: 'Processing', itemsCount: 3 },
  { id: 'ORD-7830', customerName: 'Bob Jones', email: 'bob@example.com', date: '2023-10-23', total: 149.00, status: 'Shipped', itemsCount: 1 },
  { id: 'ORD-7831', customerName: 'Charlie Day', email: 'charlie@example.com', date: '2023-10-23', total: 899.00, status: 'Delivered', itemsCount: 2 },
  { id: 'ORD-7832', customerName: 'Dana White', email: 'dana@example.com', date: '2023-10-22', total: 3200.00, status: 'Pending', itemsCount: 5 },
];

export const INITIAL_SUPPLIERS: Supplier[] = [
  { id: 'SUP-001', name: 'Nordic Home Co.', contactEmail: 'wholesale@nordichome.com', status: 'Active', productsCount: 45, rating: 4.8 },
  { id: 'SUP-002', name: 'Artisan Weaves', contactEmail: 'sales@artisanweaves.com', status: 'Active', productsCount: 12, rating: 4.9 },
  { id: 'SUP-003', name: 'Modern Metalworks', contactEmail: 'info@metalworks.com', status: 'On Hold', productsCount: 8, rating: 3.5 },
];

export const INITIAL_RENDERS: RenderLog[] = [
  { id: 'RND-101', userId: '2', prompt: 'Organic modern living room with boucle sofa', imageUrl: 'https://images.unsplash.com/photo-1600210492493-0946911123ea?w=400&h=300&fit=crop', date: '2023-10-24 14:30', status: 'success', roomType: 'Living Room' },
  { id: 'RND-102', userId: '2', prompt: 'Industrial bedroom with brick wall', imageUrl: 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?w=400&h=300&fit=crop', date: '2023-10-24 15:10', status: 'success', roomType: 'Bedroom' },
  { id: 'RND-103', userId: '3', prompt: 'Midcentury dining room teak table', imageUrl: 'https://images.unsplash.com/photo-1615875474908-f403609c4ccc?w=400&h=300&fit=crop', date: '2023-10-23 09:45', status: 'failed', roomType: 'Dining Room' },
];
