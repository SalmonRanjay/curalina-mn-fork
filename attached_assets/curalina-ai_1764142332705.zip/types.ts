
// Domain entities for Curalina AI

// Add global definition for AI Studio helper
declare global {
  interface AIStudio {
    hasSelectedApiKey: () => Promise<boolean>;
    openSelectKey: () => Promise<void>;
  }

  interface Window {
    aistudio?: AIStudio;
  }
}

export interface RoomDimensions {
  width: number;
  length: number;
  height: number;
  unit: 'feet' | 'meters' | 'inches';
  confidenceScore: number;
}

export interface ParsedRoomData {
  dimensions: RoomDimensions;
  features: string[];
  originalText: string;
}

export interface Product {
  // System Fields (Required for App Functionality)
  id: string;
  imageUrl: string; 
  images?: string[]; 
  visualDescription?: string;
  
  // --- ✅ Required Fields (12) ---
  name: string;              // "Product Name"
  description: string;       // "Overview"
  supplier: string;          // "Supplier"
  sku: string;               // "SKU"
  category: string;          // "Furniture Category"
  roomType: string;          // "Room Type"
  styleTags: string[];       // "Design Style"
  keyFeatures: string[];     // "Key Features"
  storageSolutions: string;  // "Storage Solutions"
  colors: string[];          // "Colour"
  materials: string[];       // "Product Materials"
  stock: number;             // "Inventory"

  // --- 🟨 Optional Fields (26) ---
  tradePrice?: number;       // "Trade Price"
  price: number;             // "Retail Price"
  
  // Dimensions
  dimensions: {
    h: number; // "Dimensions (Height)"
    w: number; // "Dimensions (Width)"
    d: number; // "Dimensions (Depth)"
    unit: string;
  };

  // Detailed Dimensions
  armWidth?: number;         // "Arm Width"
  armDepth?: number;         // "Arm Depth"
  seatWidth?: number;        // "Seat Width"
  seatDepth?: number;        // "Seat Depth"
  volume?: number;           // "Volume"
  doorWidth?: number;        // "Door Width"
  doorThickness?: number;    // "Door Thickness"
  doorHeight?: number;       // "Door Height"
  
  legBaseDepth1?: number;    // "Leg/Base Depth 1"
  legBaseHeight1?: number;   // "Height 1" (Leg/Base)
  legBaseWidth1?: number;    // "Width 1" (Leg/Base)
  
  tabletopThickness?: number;// "Tabletop Thickness"
  shapeType?: string;        // "Shape Type"
  
  seatingCapacity?: string;  // "Seating"
  assembly?: string;         // "Assembly"
  leadTime?: string;         // "Lead Time"
  deliveryOptions?: string;  // "Delivery Options"
  deliveryLocation?: string; // "Location"
  deliveryPolicy?: string;   // "Policy"
  tags?: string[];           // "Tags"
  weight?: number;           // "Weight (lbs)"
  
  salePrice?: number;        // Internal UI field
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'editor' | 'viewer';
  status: 'active' | 'inactive';
  lastActive: string;
  avatarUrl?: string;
}

export interface CartItem extends Product {
  quantity: number;
}

// --- New Admin Entities ---

export interface Order {
  id: string;
  customerName: string;
  email: string;
  date: string;
  total: number;
  status: 'Pending' | 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled';
  itemsCount: number;
}

export interface Supplier {
  id: string;
  name: string;
  contactEmail: string;
  status: 'Active' | 'On Hold';
  productsCount: number;
  rating: number;
}

export interface RenderLog {
  id: string;
  userId: string;
  prompt: string;
  imageUrl: string;
  date: string;
  status: 'success' | 'failed';
  roomType: string;
}

export type CsvMapping = Record<keyof Product | string, string>;

// Quiz & Design Types

export type RoomType = 'Living Room' | 'Bedroom' | 'Dining Room' | 'Home Office' | 'Entryway' | 'Nursery';

export type DesignStyle = 'Organic Modern' | 'Modern Farmhouse' | 'Midcentury Scandi' | 'Contemporary Luxe' | 'Warm Transitional' | 'Artful Eclectic';

export type ColorPalette = 'Light Neutrals' | 'Warm & Cozy' | 'Dark & Moody' | 'Fresh & Airy' | 'Earth Tones' | 'Bold & Vibrant';

export interface VibeAnalysis {
  colorPalette: string[];
  materials: string[];
  textures: string[];
  overallVibe: string;
}

export interface QuizState {
  roomType: RoomType | null;
  styles: DesignStyle[];
  palettes: ColorPalette[];
  features: string[];
  budget: string;
  vibeImages: string[]; // Base64 strings
  vibeAnalysis: VibeAnalysis | null;
  roomImage: string | null; // Base64 string
  parsedRoomData: ParsedRoomData | null;
}

export type DesignStatus = 'idle' | 'analyzing_vibe' | 'analyzing_room' | 'generating' | 'compositing' | 'complete' | 'failed';

export interface GeneratedDesign {
  id: string;
  imageUrl: string;
  products: Product[];
  promptUsed: string;
  createdAt: number;
}

export type ViewState = 'landing' | 'quiz' | 'loading' | 'results' | 'cart' | 'marketplace' | 'admin';
