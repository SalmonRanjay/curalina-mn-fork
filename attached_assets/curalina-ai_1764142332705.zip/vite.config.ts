
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, '.', '');
  return {
    plugins: [react()],
    define: {
      // Passes the Replit Secret API_KEY to the frontend
      'process.env.API_KEY': JSON.stringify(process.env.API_KEY || env.API_KEY)
    },
    server: {
      host: '0.0.0.0', // Listen on all interfaces
      proxy: {
        '/api': {
          target: 'http://localhost:3001',
          changeOrigin: true, // Needed for some virtual hosted sites
          secure: false,
          configure: (proxy, _options) => {
            proxy.on('error', (err, _req, _res) => {
              console.log('Proxy connection error:', err);
            });
            proxy.on('proxyRes', (proxyRes, req, _res) => {
               // Log success to debug terminal
               if (proxyRes.statusCode !== 404) {
                 console.log(`[Proxy] ${req.url} -> ${proxyRes.statusCode}`);
               }
            });
          }
        }
      }
    }
  };
});
