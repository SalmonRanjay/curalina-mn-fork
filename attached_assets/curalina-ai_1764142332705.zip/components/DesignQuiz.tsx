import React, { useState } from 'react';
import { QuizState, RoomType, DesignStyle, ColorPalette, ParsedRoomData } from '../types';
import { RoomParser } from './RoomParser';
import { analyzeVibeImages } from '../services/geminiService';
import { ArrowRight, Upload, Check, Loader2, Image as ImageIcon, Sparkles, ChevronLeft, Info, X } from 'lucide-react';

interface DesignQuizProps {
  onComplete: (state: QuizState) => void;
}

const ROOM_TYPES: RoomType[] = ['Living Room', 'Bedroom', 'Dining Room', 'Home Office', 'Entryway', 'Nursery'];

// Detailed Style Data
const STYLES_DATA: Record<string, {
  moodWords: string;
  textures: string;
  furniture: string;
  colorPalette: string;
  renders: string[];
}> = {
  "Midcentury Scandi": {
    moodWords: "Vintage, retro, functional, warm, clean, natural, refined",
    textures: "Woods are a staple like oak and walnut, often paired with leather, durable wools, cotton and matte metals",
    furniture: "Furniture has clean lines, soft curves, and minimalist forms, with natural wood finishes and tapered legs.",
    colorPalette: "Soft neutrals like off-white, warm beige, and light grey form a timeless base.",
    renders: [
      "https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?auto=format&fit=crop&w=400&q=80",
    ],
  },
  "Organic Modern": {
    moodWords: "Earthy, uncluttered, tranquil, zen-inspired, textural, rounded edges, plush, minimalistic",
    textures: "Breathable linens, soft cotton, cozy bouclé paired with warm oaks, tactile rugs, neutral matte stones",
    furniture: "Furniture features low-profile, minimalist designs with soft curves and sculpted edges.",
    colorPalette: "Whites, bones, chalks & earthy neutrals with small nature-inspired accents.",
    renders: [
      "https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=400&q=80",
    ],
  },
  "Modern Farmhouse": {
    moodWords: "Rustic, casual, heritage-inspired, cozy, wholesome, vintage charm, worn-in",
    textures: "Distressed and whitewashed woods, matte stones, exposed brick, knits, boucle, woven wool",
    furniture: "Oversized armchairs, plush slipcovered sofas that invite relaxation with built-in storage",
    colorPalette: "Foundational neutrals of creamy white and greige, contrasting accents of black metals.",
    renders: [
      "https://images.unsplash.com/photo-1560185893-a55cbc8c57e5?auto=format&fit=crop&w=400&q=80",
    ],
  },
  "Warm Transitional": {
    moodWords: "Timeless blend of traditional and modern, refined, classic, and polished",
    textures: "Polished metals, rich woods, velvet upholstery, chenille, bouclé, silk drapes",
    furniture: "Combines traditional curves with modern clean lines, subtle nailhead trim, piping",
    colorPalette: "Creamy white, warm greige, charcoal grey, espresso brown, bronze, brushed gold.",
    renders: [
      "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=400&q=80",
    ],
  },
  "Contemporary Luxe": {
    moodWords: "Sophisticated, minimal yet rich, polished, glamorous, refined, sleek, chic",
    textures: "Plush velvet, vegan furs, linen, leather, lacquered surfaces, smooth woods, marble",
    furniture: "Clean sculptural lines, sleek silhouettes, gentle curves, architectural forms, statement pieces",
    colorPalette: "Ivory white, warm taupe, greige, charcoal grey, matte black, espresso brown, brushed gold.",
    renders: [
      "https://images.unsplash.com/photo-1600607686527-6fb886090705?auto=format&fit=crop&w=400&q=80",
    ],
  },
  "Artful Eclectic": { // Kept for compatibility with types, used generic data if missing from prompt
     moodWords: "Bold, curated, artistic, personal, layered, unique, vibrant",
     textures: "Mix of velvet, rattan, metal, glass, patterns, and global textiles",
     furniture: "Mix of periods and styles, unique finds, custom pieces, vintage items",
     colorPalette: "Rich jewel tones, unexpected combinations, vibrant accents against neutral backdrops.",
     renders: ["https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=400&q=80"]
  }
};

const KEY_FEATURES_BY_ROOM: Record<string, Array<{ label: string; subtitle?: string }>> = {
  "Living Room": [
    { label: "Storage Solutions", subtitle: "Shelves & cabinetry" },
    { label: "Workspace Area", subtitle: "Integrated office" },
    { label: "Comfortable Seat", subtitle: "Sectional or deep sofa" },
    { label: "Accent Lighting", subtitle: "Ambient & Task" },
    { label: "Pet-Friendly", subtitle: "Durable fabrics" },
    { label: "Child-Friendly", subtitle: "Toy storage, rounded edges" },
    { label: "Media Area", subtitle: "Entertainment Cabinet" },
    { label: "Multi-Function", subtitle: "Sofa Bed" },
  ],
  "Bedroom": [
    { label: "Storage Solutions", subtitle: "Clothing & Linens" },
    { label: "Workspace Area", subtitle: "Integrated office" },
    { label: "Vanity Table", subtitle: "Makeup & Grooming" },
    { label: "Comfortable Seat", subtitle: "Reading Chair" },
    { label: "Media Area", subtitle: "TV Cabinet" },
    { label: "King Bed", subtitle: '76" wide x 80" long' },
    { label: "Queen Bed", subtitle: '60" wide x 75" long' },
  ],
  "Dining Room": [
    { label: "Casual Setting", subtitle: "Relaxed & Everyday" },
    { label: "Formal Setting", subtitle: "Elevated & Polished" },
    { label: "Bar Storage", subtitle: "Wine and Liquor" },
    { label: "Buffet Storage", subtitle: "Dishes & Linens" },
  ],
  "Home Office": [
    { label: "Concealed Storage", subtitle: "Keep clutter out" },
    { label: "Bookcase Storage", subtitle: "Open Shelves" },
    { label: "Reading Chair", subtitle: "Comfortable Seat" },
    { label: "Large Desk", subtitle: '52" to 62"' },
  ],
  "Entryway": [
      { label: "Shoe Storage", subtitle: "Racks or Cabinets" },
      { label: "Coat Storage", subtitle: "Hooks or Closet" },
      { label: "Bench Seating", subtitle: "For putting on shoes" },
      { label: "Console Table", subtitle: "Key & Mail Drop" }
  ],
  "Nursery": [
      { label: "Changing Station", subtitle: "Table or Topper" },
      { label: "Nursing Chair", subtitle: "Rocker or Glider" },
      { label: "Toy Storage", subtitle: "Accessible Bins" },
      { label: "Blackout", subtitle: "Curtains or Shades" }
  ]
};

const PALETTES: ColorPalette[] = ['Light Neutrals', 'Warm & Cozy', 'Dark & Moody', 'Fresh & Airy', 'Earth Tones', 'Bold & Vibrant'];
const BUDGETS = ['$500-$1,500', '$1,500-$3,000', '$3,000-$5,000', '$5,000+'];

export const DesignQuiz: React.FC<DesignQuizProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [state, setState] = useState<QuizState>({
    roomType: null,
    styles: [],
    palettes: [],
    features: [],
    budget: '',
    vibeImages: [],
    vibeAnalysis: null,
    roomImage: null,
    parsedRoomData: null
  });
  const [analyzingVibe, setAnalyzingVibe] = useState(false);

  const handleNext = () => setStep(s => s + 1);
  const handleBack = () => setStep(s => s - 1);

  const updateState = (key: keyof QuizState, value: any) => {
    setState(prev => ({ ...prev, [key]: value }));
  };

  const handleVibeUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const newImages: string[] = [];
      for (let i = 0; i < files.length; i++) {
        const reader = new FileReader();
        await new Promise((resolve) => {
          reader.onload = (ev) => {
            if(ev.target?.result) newImages.push(ev.target.result as string);
            resolve(true);
          };
          reader.readAsDataURL(files[i]);
        });
      }
      
      const updatedImages = [...state.vibeImages, ...newImages].slice(0, 3);
      updateState('vibeImages', updatedImages);

      setAnalyzingVibe(true);
      const analysis = await analyzeVibeImages(updatedImages);
      updateState('vibeAnalysis', analysis);
      setAnalyzingVibe(false);
    }
  };

  const handleRoomUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        updateState('roomImage', ev.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const renderStep = () => {
    switch(step) {
      case 1:
        return (
          <div className="space-y-6 animate-in slide-in-from-right duration-300">
            <div>
              <h2 className="text-3xl font-bold text-curalina-900 mb-2">Select Your Space</h2>
              <p className="text-slate-500">What room are we transforming today?</p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {ROOM_TYPES.map(type => (
                <button
                  key={type}
                  onClick={() => {
                    updateState('roomType', type);
                    // Clear features if room type changes
                    if (state.roomType !== type) updateState('features', []);
                  }}
                  className={`p-6 rounded-xl border-2 text-left transition-all hover:shadow-md ${state.roomType === type ? 'border-curalina-500 bg-curalina-50' : 'border-slate-200 hover:border-curalina-200 bg-card'}`}
                >
                  <span className={`font-semibold text-lg ${state.roomType === type ? 'text-curalina-800' : 'text-slate-700'}`}>{type}</span>
                </button>
              ))}
            </div>
          </div>
        );
      case 2:
        return (
          <div className="space-y-6 animate-in slide-in-from-right duration-300">
            <div>
              <h2 className="text-3xl font-bold text-curalina-900 mb-2">Define Your Aesthetic</h2>
              <p className="text-slate-500">Select up to 2 styles that resonate with you.</p>
            </div>
            <div className="grid grid-cols-1 gap-6">
              {Object.entries(STYLES_DATA).map(([styleName, data]) => (
                <button
                  key={styleName}
                  onClick={() => {
                    const selected = state.styles.includes(styleName as DesignStyle);
                    if (selected) {
                      updateState('styles', state.styles.filter(s => s !== styleName));
                    } else if (state.styles.length < 2) {
                      updateState('styles', [...state.styles, styleName as DesignStyle]);
                    }
                  }}
                  className={`relative group overflow-hidden rounded-xl border-2 transition-all text-left flex flex-col md:flex-row ${state.styles.includes(styleName as DesignStyle) ? 'border-curalina-500 ring-1 ring-curalina-500' : 'border-slate-200 hover:border-curalina-200'} bg-card`}
                >
                  <div className="md:w-1/3 h-48 md:h-auto relative">
                     <img src={data.renders[0]} className="w-full h-full object-cover" />
                     {state.styles.includes(styleName as DesignStyle) && (
                       <div className="absolute top-2 right-2 bg-curalina-500 text-white p-1.5 rounded-full shadow-lg">
                         <Check className="w-5 h-5" />
                       </div>
                     )}
                  </div>
                  <div className="p-6 md:w-2/3 flex flex-col justify-center">
                    <h3 className="text-xl font-bold text-slate-900 mb-2">{styleName}</h3>
                    <p className="text-sm text-slate-600 mb-3 font-medium italic">"{data.moodWords}"</p>
                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">{data.furniture}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        );
      case 3:
        return (
          <div className="space-y-6 animate-in slide-in-from-right duration-300">
            <div>
               <h2 className="text-3xl font-bold text-curalina-900 mb-2">Color Palette</h2>
               <p className="text-slate-500">Choose the tones that make you feel at home (Max 2).</p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {PALETTES.map(p => (
                <button
                  key={p}
                  onClick={() => {
                     const selected = state.palettes.includes(p);
                     if (selected) updateState('palettes', state.palettes.filter(i => i !== p));
                     else if (state.palettes.length < 2) updateState('palettes', [...state.palettes, p]);
                  }}
                  className={`h-24 p-4 rounded-xl border-2 transition-all flex items-center justify-center text-center ${state.palettes.includes(p) ? 'border-curalina-500 bg-curalina-50 text-curalina-800 font-bold' : 'border-slate-200 hover:border-slate-300 text-slate-600 bg-card font-medium'}`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>
        );
      case 4:
        const currentFeatures = state.roomType && KEY_FEATURES_BY_ROOM[state.roomType] 
            ? KEY_FEATURES_BY_ROOM[state.roomType] 
            : KEY_FEATURES_BY_ROOM["Living Room"]; // Fallback

        return (
          <div className="space-y-6 animate-in slide-in-from-right duration-300">
             <div>
                <h2 className="text-3xl font-bold text-curalina-900 mb-2">Functional Needs</h2>
                <p className="text-slate-500">What does your {state.roomType || 'space'} need to do?</p>
             </div>
             <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {currentFeatures.map((f) => (
                  <button
                    key={f.label}
                    onClick={() => {
                      const selected = state.features.includes(f.label);
                      updateState('features', selected ? state.features.filter(i => i !== f.label) : [...state.features, f.label]);
                    }}
                    className={`flex items-start gap-3 p-4 rounded-xl border-2 transition-all text-left ${state.features.includes(f.label) ? 'border-curalina-500 bg-curalina-50' : 'border-slate-200 bg-card hover:border-slate-300'}`}
                  >
                    <div className={`mt-0.5 w-5 h-5 shrink-0 rounded border flex items-center justify-center transition-colors ${state.features.includes(f.label) ? 'bg-curalina-500 border-curalina-500 text-white' : 'border-slate-300 bg-slate-50'}`}>
                      {state.features.includes(f.label) && <Check className="w-3.5 h-3.5" />}
                    </div>
                    <div>
                      <div className={`font-semibold ${state.features.includes(f.label) ? 'text-curalina-900' : 'text-slate-700'}`}>{f.label}</div>
                      {f.subtitle && <div className="text-xs text-slate-500 mt-0.5">{f.subtitle}</div>}
                    </div>
                  </button>
                ))}
             </div>
          </div>
        );
      case 5:
        return (
          <div className="space-y-6 animate-in slide-in-from-right duration-300">
             <div>
                <h2 className="text-3xl font-bold text-curalina-900 mb-2">Budget Range</h2>
                <p className="text-slate-500">This helps us recommend products within reach.</p>
             </div>
             <div className="space-y-3">
                {BUDGETS.map(b => (
                  <button
                    key={b}
                    onClick={() => updateState('budget', b)}
                    className={`w-full p-5 rounded-xl border-2 text-left transition-all flex justify-between items-center ${state.budget === b ? 'border-curalina-500 bg-curalina-50 text-curalina-900 font-bold' : 'border-slate-200 hover:border-slate-300 text-slate-600 bg-card font-medium'}`}
                  >
                    {b}
                    {state.budget === b && <Check className="w-5 h-5 text-curalina-600" />}
                  </button>
                ))}
             </div>
             <p className="text-xs text-slate-400 italic text-center mt-4">
                Note: We prioritize design quality, but try to respect your range.
             </p>
          </div>
        );
      case 6:
        return (
          <div className="space-y-6 animate-in slide-in-from-right duration-300">
             <div>
               <h2 className="text-3xl font-bold text-curalina-900 mb-2">Vibe Check</h2>
               <p className="text-slate-500">Upload inspiration photos (Pinterest, Instagram) to help AI understand your taste.</p>
             </div>
             
             <div className="grid grid-cols-3 gap-4">
                {state.vibeImages.map((img, i) => (
                  <div key={i} className="relative aspect-square rounded-xl overflow-hidden border border-slate-200 shadow-sm">
                    <img src={img} className="w-full h-full object-cover" />
                  </div>
                ))}
                {state.vibeImages.length < 3 && (
                  <label className="aspect-square rounded-xl border-2 border-dashed border-slate-300 hover:border-curalina-400 hover:bg-slate-50 cursor-pointer flex flex-col items-center justify-center text-slate-400 hover:text-curalina-600 transition-all bg-card">
                     <Upload className="w-8 h-8 mb-2" />
                     <span className="text-sm font-medium">Upload Image</span>
                     <input type="file" accept="image/*" onChange={handleVibeUpload} className="hidden" multiple />
                  </label>
                )}
             </div>

             {analyzingVibe && (
               <div className="bg-slate-100 p-4 rounded-xl flex items-center gap-3 text-sm text-slate-700 animate-pulse">
                  <Loader2 className="w-5 h-5 animate-spin text-curalina-600" />
                  Extracting colors, materials, and mood...
               </div>
             )}

             {state.vibeAnalysis && (
               <div className="bg-card p-5 rounded-xl border border-curalina-200 shadow-sm">
                  <div className="flex items-center gap-2 mb-3 text-curalina-700 font-bold uppercase tracking-wide text-xs">
                    <Sparkles className="w-4 h-4" /> AI Analysis Result
                  </div>
                  <div className="text-slate-700 mb-4 font-serif italic text-lg leading-relaxed">"{state.vibeAnalysis.overallVibe}"</div>
                  <div className="flex flex-wrap gap-2">
                    {state.vibeAnalysis.colorPalette.map((c, i) => (
                      <span key={i} className="text-xs font-medium px-3 py-1 bg-slate-100 rounded-full text-slate-700 border border-slate-200">{c}</span>
                    ))}
                  </div>
               </div>
             )}
          </div>
        );
      case 7:
        return (
          <div className="space-y-6 animate-in slide-in-from-right duration-300">
             <div>
               <h2 className="text-3xl font-bold text-curalina-900 mb-2">Your Space</h2>
               <p className="text-slate-500">Upload a photo of your actual room. We'll keep the walls, windows, and floor plan, but reimagine the rest.</p>
             </div>

             <div className="border-2 border-dashed border-slate-300 rounded-2xl p-8 text-center hover:bg-slate-50 transition-all relative bg-card group">
                {state.roomImage ? (
                  <div className="relative h-64 w-full">
                    <img src={state.roomImage} className="h-full w-full object-contain rounded-lg shadow-sm" />
                    <button 
                      onClick={() => updateState('roomImage', null)}
                      className="absolute top-2 right-2 bg-white p-1.5 rounded-full text-slate-500 hover:text-red-500 shadow-md transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <label className="cursor-pointer flex flex-col items-center justify-center h-48 w-full">
                    <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                        <ImageIcon className="w-8 h-8 text-curalina-500" />
                    </div>
                    <span className="font-bold text-lg text-slate-700">Upload Room Photo</span>
                    <span className="text-sm text-slate-400 mt-1">Supports JPG, PNG</span>
                    <input type="file" accept="image/*" onChange={handleRoomUpload} className="hidden" />
                  </label>
                )}
             </div>

             <div className="bg-blue-50 p-4 rounded-xl flex items-start gap-3">
                <Info className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                <p className="text-sm text-blue-800 leading-relaxed">
                   <strong>Pro Tip:</strong> For best results, use a wide-angle shot that shows most of the room. Ensure the room is well-lit.
                </p>
             </div>

             <div className="border-t border-slate-200 pt-6">
                <RoomParser onDataParsed={(data) => updateState('parsedRoomData', data)} />
             </div>
          </div>
        );
      default: return null;
    }
  };

  const isNextDisabled = () => {
    switch(step) {
      case 1: return !state.roomType;
      case 2: return state.styles.length === 0;
      case 3: return state.palettes.length === 0;
      case 5: return !state.budget;
      default: return false;
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-6 py-10 min-h-[80vh] flex flex-col">
      {/* Progress Bar */}
      <div className="mb-10">
        <div className="flex justify-between text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
           <span>Start</span>
           <span>Finish</span>
        </div>
        <div className="flex items-center gap-1.5 h-1.5">
          {Array.from({length: 7}).map((_, i) => (
            <div key={i} className={`h-full flex-1 rounded-full transition-all duration-500 ${i + 1 <= step ? 'bg-curalina-500' : 'bg-slate-200'}`} />
          ))}
        </div>
      </div>
      
      <div className="flex-1">
        {renderStep()}
      </div>

      <div className="flex justify-between mt-12 pt-6 border-t border-slate-200">
        <button
          onClick={handleBack}
          disabled={step === 1}
          className="px-6 py-3 rounded-xl text-slate-600 font-semibold hover:bg-slate-100 disabled:opacity-0 transition-all flex items-center gap-2"
        >
          <ChevronLeft className="w-4 h-4" /> Back
        </button>
        
        {step < 7 ? (
          <button
            onClick={handleNext}
            disabled={isNextDisabled()}
            className="px-8 py-3 rounded-xl bg-slate-900 text-white font-semibold hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-2 shadow-lg shadow-slate-200"
          >
            Next Step <ArrowRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            onClick={() => onComplete(state)}
            className="px-8 py-3 rounded-xl bg-gradient-to-r from-curalina-500 to-curalina-600 text-white font-bold hover:from-curalina-600 hover:to-curalina-700 shadow-lg shadow-curalina-200 transition-all flex items-center gap-2 transform hover:-translate-y-0.5"
          >
            Generate My Design <Sparkles className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};