import React, { useState, useEffect } from 'react';
import { Lock, Mail, ArrowRight, ShieldCheck, Server, RefreshCw, CheckCircle, XCircle } from 'lucide-react';
import { db } from '../services/db';

interface AdminLoginProps {
  onLogin: () => void;
  onCancel: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onLogin, onCancel }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Connection State
  const [serverStatus, setServerStatus] = useState<'checking' | 'connected' | 'disconnected'>('checking');

  const checkConnection = async () => {
    setServerStatus('checking');
    const isConnected = await db.init();
    setServerStatus(isConnected ? 'connected' : 'disconnected');
  };

  useEffect(() => {
    checkConnection();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // Mock authentication delay
    setTimeout(() => {
      if (email === 'admin@curalina.ai' && password === 'admin123') {
        onLogin();
      } else {
        setError('Invalid credentials. Try admin@curalina.ai / admin123');
        setLoading(false);
      }
    }, 1000);
  };

  return (
    <div className="fixed inset-0 bg-slate-100 flex items-center justify-center z-50">
      <div className="bg-card w-full max-w-md rounded-2xl shadow-xl border border-slate-200 overflow-hidden animate-in zoom-in duration-300">
        <div className="bg-slate-900 p-8 text-center relative">
          <div className="w-12 h-12 bg-curalina-500 rounded-xl flex items-center justify-center mx-auto mb-4 text-white shadow-lg shadow-curalina-900/50">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <h2 className="text-2xl font-bold text-white">Curalina Admin</h2>
          <p className="text-slate-400 text-sm mt-2">Secure access for platform management</p>
          
          {/* Connection Status Badge */}
          <div className="absolute top-4 right-4">
             {serverStatus === 'checking' && <div className="p-2 bg-slate-800 rounded-full animate-spin"><RefreshCw className="w-4 h-4 text-slate-400"/></div>}
             {serverStatus === 'connected' && (
                <div className="flex items-center gap-1.5 px-2 py-1 bg-green-500/20 rounded-full border border-green-500/30 text-green-400 text-xs font-medium">
                   <CheckCircle className="w-3 h-3" /> Server Online
                </div>
             )}
             {serverStatus === 'disconnected' && (
                <button onClick={checkConnection} className="flex items-center gap-1.5 px-2 py-1 bg-red-500/20 rounded-full border border-red-500/30 text-red-400 text-xs font-medium hover:bg-red-500/30 transition-colors">
                   <XCircle className="w-3 h-3" /> Local Mode (Retry?)
                </button>
             )}
          </div>
        </div>

        <div className="p-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                <input 
                  type="email" 
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-curalina-500 focus:border-transparent outline-none transition-all bg-slate-50"
                  placeholder="name@company.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                <input 
                  type="password" 
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-curalina-500 focus:border-transparent outline-none transition-all bg-slate-50"
                  placeholder="••••••••"
                />
              </div>
            </div>

            {error && (
              <div className="p-3 bg-red-50 text-red-600 text-sm rounded-lg border border-red-100 flex items-center justify-center">
                {error}
              </div>
            )}

            <button 
              type="submit" 
              disabled={loading}
              className="w-full bg-slate-900 text-white py-3 rounded-lg font-bold hover:bg-slate-800 transition-all flex items-center justify-center gap-2 shadow-lg disabled:opacity-70"
            >
              {loading ? 'Authenticating...' : (
                <>Sign In <ArrowRight className="w-4 h-4" /></>
              )}
            </button>
            
            <button 
              type="button"
              onClick={onCancel}
              className="w-full text-sm text-slate-500 hover:text-slate-800 transition-colors"
            >
              Return to Website
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};