
import React from 'react';
import { Product } from '../types';
import { ShoppingCart, Repeat, ImageOff } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onAddToCart: (p: Product) => void;
  onSwap?: (p: Product) => void;
  isCompact?: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart, onSwap, isCompact = false }) => {
  const hasDiscount = product.salePrice && product.salePrice < product.price;
  const discountPct = hasDiscount ? Math.round(((product.price - product.salePrice!) / product.price) * 100) : 0;

  const ImagePlaceholder = () => (
    <div className="w-full h-full flex flex-col items-center justify-center bg-slate-100 text-slate-300">
      <ImageOff className="w-8 h-8 mb-1" />
      <span className="text-[10px] font-medium uppercase tracking-wider">No Image</span>
    </div>
  );

  if (isCompact) {
    return (
      <div className="flex gap-4 p-3 bg-card rounded-lg border border-slate-200 group hover:border-curalina-200 transition-colors">
        <div className="w-24 h-24 shrink-0 rounded-md overflow-hidden bg-slate-50 relative">
          {product.imageUrl ? (
            <img 
              src={product.imageUrl} 
              alt={product.name} 
              className="w-full h-full object-cover" 
              onError={(e) => {
                e.currentTarget.style.display = 'none';
                e.currentTarget.parentElement?.classList.add('flex', 'items-center', 'justify-center');
                // Render simple fallback via DOM manip for error case is tricky in react, simpler to just hide and show background
              }}
            />
          ) : (
            <ImagePlaceholder />
          )}
          {hasDiscount && (
            <div className="absolute top-1 right-1 bg-green-500 text-white text-[10px] font-bold px-1.5 rounded">
              -{discountPct}%
            </div>
          )}
        </div>
        <div className="flex-1 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-start">
              <h4 className="text-sm font-medium text-slate-900 line-clamp-1">{product.name}</h4>
              <button onClick={() => onSwap && onSwap(product)} className="text-slate-400 hover:text-curalina-600 p-1">
                <Repeat className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-slate-500">{product.category}</p>
          </div>
          
          <div className="flex items-end justify-between mt-2">
            <div>
               {hasDiscount ? (
                 <div className="flex items-baseline gap-1.5">
                   <span className="text-sm font-bold text-green-700">${product.salePrice}</span>
                   <span className="text-xs text-slate-400 line-through">${product.price}</span>
                 </div>
               ) : (
                 <span className="text-sm font-bold text-slate-900">${product.price}</span>
               )}
            </div>
            <button 
              onClick={() => onAddToCart(product)}
              className="bg-slate-900 text-white p-2 rounded-full hover:bg-slate-800 transition-colors"
            >
              <ShoppingCart className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-md transition-all group flex flex-col h-full">
      <div className="relative aspect-[4/3] bg-slate-100 overflow-hidden">
        {product.imageUrl ? (
           <img 
             src={product.imageUrl} 
             alt={product.name} 
             className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
             onError={(e) => {
                e.currentTarget.style.display = 'none';
                // Sibling placeholder logic requires state or ref which is heavy for a list, 
                // instead we rely on the parent container background if image hides
                e.currentTarget.parentElement!.innerHTML = '<div class="w-full h-full flex flex-col items-center justify-center text-slate-300"><svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="2" x2="22" y1="2" y2="22"/><path d="M10.41 10.41a2 2 0 1 1-2.83-2.83"/><line x1="15" x2="15" y1="2" y2="2"/><line x1="19" x2="19" y1="2" y2="2"/></svg><span class="text-[10px] mt-2 font-medium uppercase">No Image</span></div>';
             }}
           />
        ) : (
           <ImagePlaceholder />
        )}
        {hasDiscount && (
          <div className="absolute top-3 left-3 bg-green-500 text-white px-2 py-1 rounded text-xs font-bold shadow-sm">
            Save {discountPct}%
          </div>
        )}
      </div>
      
      <div className="p-4 flex-1 flex flex-col">
        <div className="mb-2">
           <p className="text-xs text-slate-500 uppercase tracking-wide font-medium">{product.category}</p>
           <h4 className="font-semibold text-slate-900 line-clamp-1 mt-0.5">{product.name}</h4>
        </div>

        <p className="text-xs text-slate-500 line-clamp-2 mb-4 leading-relaxed">{product.visualDescription || product.description}</p>
        
        <div className="mt-auto flex items-end justify-between border-t border-slate-200 pt-4">
           <div>
              {hasDiscount ? (
                 <div className="flex flex-col">
                   <span className="text-xs text-slate-400 line-through">${product.price}</span>
                   <span className="text-lg font-bold text-green-600">${product.salePrice}</span>
                 </div>
               ) : (
                 <span className="text-lg font-bold text-slate-900">${product.price}</span>
               )}
           </div>
           
           <button 
             onClick={() => onAddToCart(product)}
             className="bg-slate-100 hover:bg-slate-900 text-slate-900 hover:text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
           >
             <ShoppingCart className="w-4 h-4" /> Add
           </button>
        </div>
      </div>
    </div>
  );
};
