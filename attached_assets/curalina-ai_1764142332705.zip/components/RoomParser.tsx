import React, { useState } from 'react';
import { parseRoomDescription } from '../services/geminiService';
import { ParsedRoomData } from '../types';
import { CheckCircle, AlertTriangle, Loader2 } from 'lucide-react';

interface RoomParserProps {
  onDataParsed: (data: ParsedRoomData) => void;
}

export const RoomParser: React.FC<RoomParserProps> = ({ onDataParsed }) => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ParsedRoomData | null>(null);

  const handleParse = async () => {
    if (!input.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const data = await parseRoomDescription(input);
      setResult(data);
      onDataParsed(data);
    } catch (e) {
      setError("Failed to process room description. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-card p-6 rounded-xl shadow-sm border border-slate-200">
      <h3 className="text-lg font-semibold text-slate-800 mb-2">Room Dimensions</h3>
      <p className="text-sm text-slate-500 mb-4">
        Describe your room naturally (e.g., "15x12 ft living room with 10ft ceilings and a large bay window"). 
        Our AI will extract the data.
      </p>

      <div className="relative">
        <textarea
          className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-curalina-500 focus:border-transparent outline-none transition-all resize-none h-24 text-slate-700 bg-slate-50"
          placeholder="Enter room details..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <button
          onClick={handleParse}
          disabled={loading || !input}
          className="absolute bottom-3 right-3 bg-curalina-600 text-white px-4 py-1.5 rounded-md text-sm font-medium hover:bg-curalina-700 disabled:opacity-50 flex items-center gap-2 transition-colors"
        >
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Analyze'}
        </button>
      </div>

      {error && (
        <div className="mt-3 text-red-500 text-sm flex items-center gap-2">
          <AlertTriangle className="w-4 h-4" />
          {error}
        </div>
      )}

      {result && (
        <div className="mt-4 p-4 bg-slate-50 rounded-lg border border-slate-200 animate-in fade-in slide-in-from-top-2 duration-300">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-sm font-semibold text-slate-700">Analysis Result</span>
                {result.dimensions.confidenceScore > 0.7 ? (
                  <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <CheckCircle className="w-3 h-3" /> High Confidence
                  </span>
                ) : (
                  <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" /> Verify Details
                  </span>
                )}
              </div>
              <div className="grid grid-cols-3 gap-4 mt-2">
                <div className="bg-white p-2 rounded border border-slate-100 text-center">
                  <div className="text-xs text-slate-400 uppercase tracking-wider">Width</div>
                  <div className="font-mono font-medium text-slate-800">{result.dimensions.width} {result.dimensions.unit}</div>
                </div>
                <div className="bg-white p-2 rounded border border-slate-100 text-center">
                  <div className="text-xs text-slate-400 uppercase tracking-wider">Length</div>
                  <div className="font-mono font-medium text-slate-800">{result.dimensions.length} {result.dimensions.unit}</div>
                </div>
                <div className="bg-white p-2 rounded border border-slate-100 text-center">
                  <div className="text-xs text-slate-400 uppercase tracking-wider">Height</div>
                  <div className="font-mono font-medium text-slate-800">{result.dimensions.height} {result.dimensions.unit}</div>
                </div>
              </div>
              {result.features.length > 0 && (
                <div className="mt-2 text-xs text-slate-500">
                  <span className="font-medium">Detected Features:</span> {result.features.join(", ")}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};