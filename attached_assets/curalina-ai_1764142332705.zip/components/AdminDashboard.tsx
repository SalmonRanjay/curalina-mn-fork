
import React, { useState, useMemo } from 'react';
import { Product, User, Order, Supplier, RenderLog } from '../types';
import { analyzeProductImage } from '../services/geminiService';
import { db } from '../services/db';
import { 
  Upload, Plus, FileSpreadsheet, Image as ImageIcon, Loader2, Check, X, 
  Folder, FolderInput, LayoutDashboard, Users, Package, Settings, LogOut,
  Search, MoreVertical, Shield, Mail, Calendar, BarChart3, ShoppingCart,
  Truck, Database, BrainCircuit, BookOpen, ChevronRight, AlertCircle, AlertTriangle, FileDown,
  Filter, List, Grid3X3, Tag, DollarSign, RefreshCcw, Download, Link, ArrowRightLeft, ImageOff
} from 'lucide-react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  BarChart, Bar, Legend 
} from 'recharts';

interface AdminDashboardProps {
  products: Product[];
  users: User[];
  orders: Order[];
  suppliers: Supplier[];
  renders: RenderLog[];
  onAddProduct: (product: Product) => void;
  onBulkAddProducts: (products: Product[]) => void;
  onBulkUpsertProducts?: (products: Product[]) => void;
  onAddUser: (user: User) => void;
  onLogout: () => void;
}

type Section = 'overview' | 'analytics' | 'products' | 'orders' | 'suppliers' | 'renders' | 'quiz-mapping' | 'users' | 'documentation' | 'settings';
type ProductTab = 'catalog' | 'single' | 'bulk_csv' | 'bulk_img';

interface CsvImportError {
  row: number;
  message: string;
  rawData: string;
}

// ✅ Required Fields (12) - EXACT SPELLING
const REQUIRED_FIELDS = [
    { key: 'name', label: 'Product Name' },
    { key: 'description', label: 'Overview' },
    { key: 'supplier', label: 'Supplier' },
    { key: 'sku', label: 'SKU' },
    { key: 'category', label: 'Furniture Category' },
    { key: 'roomType', label: 'Room Type' },
    { key: 'styleTags', label: 'Design Style' },
    { key: 'keyFeatures', label: 'Key Features' },
    { key: 'storageSolutions', label: 'Storage Solutions' },
    { key: 'colors', label: 'Colour' },
    { key: 'materials', label: 'Product Materials' },
    { key: 'stock', label: 'Inventory' }
];

// 🟨 Optional Fields (26) - EXACT SPELLING
const AVAILABLE_FIELDS = [
    { key: 'tradePrice', label: 'Trade Price' },
    { key: 'price', label: 'Retail Price' },
    { key: 'dimensions.h', label: 'Dimensions (Height)' },
    { key: 'dimensions.w', label: 'Dimensions (Width)' },
    { key: 'dimensions.d', label: 'Dimensions (Depth)' },
    { key: 'armWidth', label: 'Arm Width' },
    { key: 'armDepth', label: 'Arm Depth' },
    { key: 'seatWidth', label: 'Seat Width' },
    { key: 'seatDepth', label: 'Seat Depth' },
    { key: 'volume', label: 'Volume' },
    { key: 'doorWidth', label: 'Door Width' },
    { key: 'doorThickness', label: 'Door Thickness' },
    { key: 'doorHeight', label: 'Door Height' },
    { key: 'legBaseDepth1', label: 'Leg/Base Depth 1' },
    { key: 'legBaseHeight1', label: 'Height 1' },
    { key: 'legBaseWidth1', label: 'Width 1' },
    { key: 'tabletopThickness', label: 'Tabletop Thickness' },
    { key: 'shapeType', label: 'Shape Type' },
    { key: 'seatingCapacity', label: 'Seating' },
    { key: 'assembly', label: 'Assembly' },
    { key: 'leadTime', label: 'Lead Time' },
    { key: 'deliveryOptions', label: 'Delivery Options' },
    { key: 'deliveryLocation', label: 'Location' },
    { key: 'deliveryPolicy', label: 'Policy' },
    { key: 'tags', label: 'Tags' },
    { key: 'weight', label: 'Weight (lbs)' },
    // System Fields
    { key: 'imageUrl', label: 'Image URL' }
];

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ 
  products, 
  users, 
  orders,
  suppliers,
  renders,
  onAddProduct, 
  onBulkAddProducts, 
  onBulkUpsertProducts,
  onAddUser,
  onLogout 
}) => {
  const [activeSection, setActiveSection] = useState<Section>('overview');
  const [productTab, setProductTab] = useState<ProductTab>('catalog');
  
  // --- User Management State ---
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [newUser, setNewUser] = useState<{name: string; email: string; role: 'admin' | 'editor' | 'viewer'}>({ 
    name: '', 
    email: '', 
    role: 'editor' 
  });

  // --- Product Catalog Filter State ---
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [priceRange, setPriceRange] = useState<'All' | 'Low' | 'Medium' | 'High'>('All');

  // --- Product Management State ---
  const [analyzing, setAnalyzing] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<Product>>({
    name: '', category: 'Seating', price: 0, description: '', 
    materials: [], colors: [], styleTags: [], dimensions: { w: 0, d: 0, h: 0, unit: 'inches' },
    keyFeatures: [], storageSolutions: 'None', stock: 0
  });
  
  // Bulk Image / Folder
  const [detectedProducts, setDetectedProducts] = useState<(Product & { isUpdate: boolean })[]>([]);
  const [processingFolder, setProcessingFolder] = useState(false);
  
  // CSV State
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const [csvRows, setCsvRows] = useState<string[][]>([]);
  const [showMapper, setShowMapper] = useState(false);
  const [columnMapping, setColumnMapping] = useState<Record<string, string>>({});
  
  const [csvPreview, setCsvPreview] = useState<Product[]>([]);
  const [importErrors, setImportErrors] = useState<CsvImportError[]>([]);

  // --- Derived Data ---
  const filteredCatalog = useMemo(() => {
    return products.filter(p => {
      const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            (p.sku && p.sku.toLowerCase().includes(searchTerm.toLowerCase())) ||
                            p.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            p.category.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = categoryFilter === 'All' || p.category === categoryFilter;
      
      let matchesPrice = true;
      if (priceRange === 'Low') matchesPrice = p.price < 500;
      if (priceRange === 'Medium') matchesPrice = p.price >= 500 && p.price < 1500;
      if (priceRange === 'High') matchesPrice = p.price >= 1500;

      return matchesSearch && matchesCategory && matchesPrice;
    });
  }, [products, searchTerm, categoryFilter, priceRange]);

  const categories = useMemo(() => ['All', ...Array.from(new Set(products.map(p => p.category))).sort()], [products]);

  // --- Handlers: Product ---
  
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (ev) => {
        const result = ev.target?.result as string;
        setImagePreview(result);
        setAnalyzing(true);
        try {
          const analysis = await analyzeProductImage(result);
          setFormData(prev => ({
            ...prev, imageUrl: result, ...analysis, name: prev.name || '', price: prev.price || 0
          }));
        } catch (err) { console.error(err); } finally { setAnalyzing(false); }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmitProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !imagePreview) return;
    const newProduct: Product = {
      id: crypto.randomUUID(),
      name: formData.name!,
      description: formData.description || '',
      supplier: formData.supplier || 'Unknown',
      sku: formData.sku || `GEN-${Date.now()}`,
      category: formData.category || 'Decor',
      roomType: formData.roomType || 'Any',
      styleTags: formData.styleTags || [],
      keyFeatures: formData.keyFeatures || [],
      storageSolutions: formData.storageSolutions || 'None',
      colors: formData.colors || [],
      materials: formData.materials || [],
      stock: formData.stock || 1,
      price: Number(formData.price) || 0,
      imageUrl: imagePreview,
      visualDescription: formData.visualDescription,
      dimensions: { 
        w: Number(formData.dimensions?.w) || 0, 
        d: Number(formData.dimensions?.d) || 0, 
        h: Number(formData.dimensions?.h) || 0, 
        unit: 'inches' 
      }
    };
    onAddProduct(newProduct);
    setFormData({ 
       name: '', category: 'Seating', price: 0, description: '', 
       materials: [], colors: [], styleTags: [], 
       dimensions: { w: 0, d: 0, h: 0, unit: 'inches' } 
    });
    setImagePreview(null);
    alert('Product added successfully!');
  };

  // Robust CSV Parser
  const parseCSV = (text: string): string[][] => {
    const rows: string[][] = [];
    let currentRow: string[] = [];
    let currentField = '';
    let insideQuotes = false;
    
    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      const nextChar = text[i + 1];

      if (char === '"') {
        if (insideQuotes && nextChar === '"') {
          currentField += '"';
          i++; 
        } else {
          insideQuotes = !insideQuotes;
        }
      } else if (char === ',' && !insideQuotes) {
        currentRow.push(currentField.trim());
        currentField = '';
      } else if ((char === '\r' || char === '\n') && !insideQuotes) {
        if (char === '\r' && nextChar === '\n') i++; 
        currentRow.push(currentField.trim());
        if (currentRow.some(cell => cell)) rows.push(currentRow);
        currentRow = [];
        currentField = '';
      } else {
        currentField += char;
      }
    }
    if (currentField || currentRow.length > 0) {
      currentRow.push(currentField.trim());
      if (currentRow.some(cell => cell)) rows.push(currentRow);
    }
    return rows;
  };

  const downloadCSVTemplate = () => {
    // Exact headers from user request
    const headers = [
      "Product Name", "Overview", "Supplier", "SKU", "Furniture Category", "Room Type", 
      "Design Style", "Key Features", "Storage Solutions", "Colour", "Product Materials", "Inventory",
      "Trade Price", "Retail Price", "Dimensions (Height)", "Dimensions (Width)", "Dimensions (Depth)",
      "Arm Width", "Arm Depth", "Seat Width", "Seat Depth", "Volume",
      "Door Width", "Door Thickness", "Door Height",
      "Leg/Base Depth 1", "Height 1", "Width 1",
      "Tabletop Thickness", "Shape Type", "Seating", "Assembly", "Lead Time",
      "Delivery Options", "Location", "Policy", "Tags", "Weight (lbs)", "Image URL"
    ];
    
    // Example Row
    const row = [
      "Cloud Sofa", "Curved boucle sofa", "Nordic Home", "SOFA-001", "Seating", "Living Room",
      "Organic Modern", "Curved,Soft", "None", "Cream", "Boucle,Oak", "15",
      "800", "1499", "32", "84", "38",
      "10", "38", "60", "24", "45",
      "32", "2", "80",
      "38", "4", "4",
      "0", "Curved", "3", "No", "7 days",
      "White Glove", "US", "Free Returns", "modern,luxury", "150", "https://example.com/image.jpg"
    ];

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), row.join(",")].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "curalina_import_template.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleBulkImportCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setCsvFile(file);
    setCsvPreview([]);
    setImportErrors([]);
    setColumnMapping({});

    const reader = new FileReader();
    reader.onload = (ev) => {
        const content = ev.target?.result as string;
        if (!content) return;
        
        const rows = parseCSV(content);
        if (rows.length < 2) {
           setImportErrors([{ row: 0, message: "File is empty or missing header row.", rawData: "" }]);
           return;
        }

        const headers = rows[0];
        setCsvHeaders(headers);
        setCsvRows(rows.slice(1));
        
        // Auto-map based on exact label matches first, then fuzzy
        const autoMap: Record<string, string> = {};
        
        const allFields = [...REQUIRED_FIELDS, ...AVAILABLE_FIELDS];
        
        headers.forEach(h => {
           const headerLower = h.toLowerCase().trim();
           
           // Find exact or close match in our system fields
           const match = allFields.find(f => {
               const labelLower = f.label.toLowerCase();
               return headerLower === labelLower || 
                      headerLower.replace(/[^a-z0-9]/g, '') === labelLower.replace(/[^a-z0-9]/g, '');
           });

           if (match) {
               autoMap[match.key] = h;
           }
        });
        
        setColumnMapping(autoMap);
        setShowMapper(true);
        e.target.value = '';
    };
    reader.readAsText(file);
  };

  const processMappedCSV = () => {
    const newProducts: Product[] = [];
    const errors: CsvImportError[] = [];

    csvRows.forEach((cols, i) => {
        const val = (key: string) => {
            const headerName = columnMapping[key];
            const idx = csvHeaders.indexOf(headerName);
            return idx > -1 && cols[idx] ? cols[idx] : '';
        };
        const num = (key: string) => parseFloat(val(key).replace(/[^0-9.]/g, '')) || 0;

        const name = val('name');
        const sku = val('sku');
        
        if (!name || !sku) {
           errors.push({ row: i + 1, message: `Missing Name or SKU.`, rawData: cols.join(',') });
           return;
        }

        const p: Product = {
            id: crypto.randomUUID(),
            sku: sku,
            name: name,
            description: val('description') || `Imported product ${sku}`,
            supplier: val('supplier') || 'Unknown',
            category: val('category') || 'Uncategorized',
            roomType: val('roomType') || 'Any',
            styleTags: val('styleTags').split(',').map(s => s.trim()).filter(s => s),
            keyFeatures: val('keyFeatures').split(',').map(s => s.trim()).filter(s => s),
            storageSolutions: val('storageSolutions') || 'None',
            colors: val('colors').split(',').map(s => s.trim()).filter(s => s),
            materials: val('materials').split(',').map(s => s.trim()).filter(s => s),
            stock: Math.floor(num('stock')) || 0,
            
            tradePrice: num('tradePrice'),
            price: num('price') || 0,
            
            dimensions: {
               h: num('dimensions.h'),
               w: num('dimensions.w'),
               d: num('dimensions.d'),
               unit: 'inches'
            },
            
            // New Optional Fields
            armWidth: num('armWidth'),
            armDepth: num('armDepth'),
            seatWidth: num('seatWidth'),
            seatDepth: num('seatDepth'),
            volume: num('volume'),
            doorWidth: num('doorWidth'),
            doorThickness: num('doorThickness'),
            doorHeight: num('doorHeight'),
            legBaseDepth1: num('legBaseDepth1'),
            legBaseHeight1: num('legBaseHeight1'),
            legBaseWidth1: num('legBaseWidth1'),
            tabletopThickness: num('tabletopThickness'),
            shapeType: val('shapeType'),
            seatingCapacity: val('seatingCapacity'),
            assembly: val('assembly'),
            leadTime: val('leadTime'),
            deliveryOptions: val('deliveryOptions'),
            deliveryLocation: val('deliveryLocation'),
            deliveryPolicy: val('deliveryPolicy'),
            tags: val('tags').split(',').map(s => s.trim()).filter(s => s),
            weight: num('weight'),

            imageUrl: val('imageUrl') || '', // Use empty string if missing to trigger fallback
        };
        newProducts.push(p);
    });

    setCsvPreview(newProducts);
    setImportErrors(errors);
    setShowMapper(false);
  };

  const confirmCSVImport = () => {
    if (csvPreview.length > 0) {
      if (onBulkUpsertProducts) {
         onBulkUpsertProducts(csvPreview);
      } else {
         onBulkAddProducts(csvPreview);
      }
      setCsvPreview([]);
      setImportErrors([]);
      alert(`Successfully imported ${csvPreview.length} products.`);
    }
  };

  const handleFolderUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setProcessingFolder(true);
    setDetectedProducts([]);
    
    const productMap = new Map<string, { category: string, images: string[], sku: string }>();
    
    Array.from(files).forEach((file: any) => {
      if (file.name.startsWith('.')) return;
      const pathParts = file.webkitRelativePath.split('/');
      if (pathParts.length < 2) return;
      const fileName = pathParts[pathParts.length - 1];
      if (!fileName.match(/\.(jpg|jpeg|png|webp)$/i)) return;
      
      // Robust SKU extraction: parent folder name
      const skuNameRaw = pathParts[pathParts.length - 2];
      const skuName = skuNameRaw.trim();
      
      const category = pathParts.length >= 3 ? pathParts[pathParts.length - 3] : 'Uncategorized';
      
      if (!productMap.has(skuName)) {
         productMap.set(skuName, { category, images: [], sku: skuName });
      }
      const reader = new FileReader();
      reader.onload = (ev) => {
          if (ev.target?.result) {
              const base64 = ev.target.result as string;
              productMap.get(skuName)?.images.push(base64);
          }
      };
      reader.readAsDataURL(file);
    });

    // Wait for all file reads
    setTimeout(() => {
        const preparedProducts: (Product & { isUpdate: boolean })[] = Array.from(productMap.entries()).map(([skuName, data]) => {
           // SMART MATCHING: Case insensitive, ignore spaces/dashes
           const normalize = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
           const targetSku = normalize(skuName);
           
           const existing = products.find(p => 
              normalize(p.sku) === targetSku || 
              normalize(p.name) === targetSku || 
              p.id === skuName
           );

           if (existing) {
              return {
                 ...existing,
                 images: [...(existing.images || []), ...data.images],
                 imageUrl: data.images[0], // Update display image
                 isUpdate: true
              };
           } else {
              return {
                 id: crypto.randomUUID(), sku: skuName, name: skuName.replace(/[-_]/g, ' '), 
                 description: `Imported from folder: ${skuName}`,
                 supplier: 'Unknown', category: data.category, roomType: 'Any',
                 price: 0, stock: 0, styleTags: [], keyFeatures: [], storageSolutions: 'None', colors: [], materials: [],
                 dimensions: { w: 0, d: 0, h: 0, unit: 'inches' }, 
                 imageUrl: data.images[0], images: data.images, isUpdate: false
              };
           }
        });
        setDetectedProducts(preparedProducts);
        setProcessingFolder(false);
    }, 2000); // Increased timeout for larger folder sets
  };
  
  const confirmFolderImport = () => {
    if (detectedProducts.length > 0) {
      if(onBulkUpsertProducts) onBulkUpsertProducts(detectedProducts);
      else onBulkAddProducts(detectedProducts);
      setDetectedProducts([]);
      alert(`Updated ${detectedProducts.length} items from folders.`);
    }
  };

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    onAddUser({
      id: crypto.randomUUID(),
      ...newUser,
      status: 'active',
      lastActive: new Date().toLocaleDateString()
    });
    setIsUserModalOpen(false);
    setNewUser({ name: '', email: '', role: 'editor' });
  };

  const Sidebar = () => (
    <div className="w-64 bg-slate-900 text-slate-300 flex flex-col h-full sticky top-0 shrink-0">
      <div className="p-6 border-b border-slate-800 flex items-center gap-3">
        <div className="w-8 h-8 bg-curalina-500 rounded-lg flex items-center justify-center text-white font-bold">C</div>
        <span className="font-bold text-white text-lg">Curalina Admin</span>
      </div>
      <div className="flex-1 overflow-y-auto">
        <nav className="p-4 space-y-1">
          {[
            { id: 'overview', icon: LayoutDashboard, label: 'Overview' },
            { id: 'analytics', icon: BarChart3, label: 'Analytics' },
            { id: 'orders', icon: ShoppingCart, label: 'Orders' },
            { id: 'products', icon: Package, label: 'Products' },
            { id: 'suppliers', icon: Truck, label: 'Suppliers' },
            { id: 'renders', icon: Database, label: 'Renders Storage' },
            { id: 'quiz-mapping', icon: BrainCircuit, label: 'Quiz Mapping' },
            { id: 'users', icon: Users, label: 'Users' },
            { id: 'documentation', icon: BookOpen, label: 'Documentation' },
            { id: 'settings', icon: Settings, label: 'Settings' }
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveSection(item.id as Section)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeSection === item.id ? 'bg-curalina-600 text-white' : 'hover:bg-slate-800 hover:text-white'}`}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
        </nav>
      </div>
      <div className="p-4 border-t border-slate-800">
         <div className="px-4 py-2 mb-2 bg-slate-800/50 rounded flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </span>
            <span className="text-xs font-mono text-slate-400">{db.status()}</span>
         </div>
         <button onClick={onLogout} className="w-full mt-2 flex items-center gap-2 px-4 py-2 text-sm text-red-400 hover:bg-slate-800 rounded-lg transition-colors">
            <LogOut className="w-4 h-4" /> Sign Out
         </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 flex font-sans overflow-hidden h-screen">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
         <header className="h-16 bg-card border-b border-slate-200 flex items-center justify-between px-8 shrink-0">
            <h2 className="text-xl font-bold text-slate-800 capitalize">{activeSection.replace('-', ' ')}</h2>
            <div className="flex items-center gap-4">
               <button className="p-2 text-slate-400 hover:bg-slate-50 rounded-full"><Mail className="w-5 h-5" /></button>
            </div>
         </header>
         <main className="flex-1 p-8 overflow-y-auto">
            {activeSection === 'products' && (
              <div className="bg-card rounded-xl border border-slate-200 shadow-sm overflow-hidden animate-in fade-in">
                <div className="border-b border-slate-200 bg-slate-50/50 flex overflow-x-auto">
                  {[
                    { id: 'catalog', label: 'Product Catalog', icon: List },
                    { id: 'single', label: 'Add Single', icon: Plus },
                    { id: 'bulk_csv', label: 'Bulk CSV Import', icon: FileSpreadsheet },
                    { id: 'bulk_img', label: 'Folder Connect', icon: FolderInput }
                  ].map(tab => (
                    <button
                      key={tab.id}
                      onClick={() => setProductTab(tab.id as ProductTab)}
                      className={`flex items-center gap-2 px-6 py-4 text-sm font-medium transition-all border-b-2 ${productTab === tab.id ? 'border-curalina-600 text-curalina-700 bg-card' : 'border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-50'}`}
                    >
                      <tab.icon className="w-4 h-4" /> {tab.label}
                    </button>
                  ))}
                </div>
                
                <div className="p-8">
                  {/* CSV MAPPING MODAL */}
                  {showMapper && (
                     <div className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-4">
                        <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col animate-in zoom-in duration-200">
                           <div className="p-6 border-b border-slate-200 flex justify-between items-center bg-slate-50 rounded-t-xl">
                              <div>
                                <h3 className="text-xl font-bold text-slate-900">Map CSV Columns</h3>
                                <p className="text-sm text-slate-500">Match your file headers to Curalina system fields.</p>
                              </div>
                              <button onClick={() => setShowMapper(false)} className="text-slate-400 hover:text-red-500"><X className="w-6 h-6"/></button>
                           </div>
                           <div className="flex-1 overflow-y-auto p-6 grid md:grid-cols-2 gap-8">
                              <div>
                                 <h4 className="font-bold mb-4 flex items-center gap-2 text-curalina-600"><Check className="w-4 h-4"/> Required Fields</h4>
                                 <div className="space-y-4">
                                    {REQUIRED_FIELDS.map(field => (
                                       <div key={field.key} className="flex flex-col gap-1">
                                          <label className="text-sm font-medium text-slate-700">{field.label}</label>
                                          <div className="flex items-center gap-2">
                                             <select 
                                                className={`flex-1 p-2 border rounded-lg outline-none ${!columnMapping[field.key] ? 'border-red-300 bg-red-50' : 'border-curalina-200 bg-curalina-50'}`}
                                                value={columnMapping[field.key] || ''}
                                                onChange={e => setColumnMapping({...columnMapping, [field.key]: e.target.value})}
                                             >
                                                <option value="">-- Select Header --</option>
                                                {csvHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                                             </select>
                                          </div>
                                       </div>
                                    ))}
                                 </div>
                              </div>
                              <div>
                                 <h4 className="font-bold mb-4 text-slate-600">Optional Fields</h4>
                                 <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2">
                                    {AVAILABLE_FIELDS.map(field => (
                                       <div key={field.key} className="flex flex-col gap-1">
                                          <label className="text-sm font-medium text-slate-700">{field.label}</label>
                                          <select 
                                             className="w-full p-2 border border-slate-200 rounded-lg outline-none focus:border-curalina-500"
                                             value={columnMapping[field.key] || ''}
                                             onChange={e => setColumnMapping({...columnMapping, [field.key]: e.target.value})}
                                          >
                                             <option value="">-- Ignore --</option>
                                             {csvHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                                          </select>
                                       </div>
                                    ))}
                                 </div>
                              </div>
                           </div>
                           <div className="p-6 border-t border-slate-200 bg-slate-50 rounded-b-xl flex justify-end gap-3">
                              <button onClick={() => setShowMapper(false)} className="px-6 py-2.5 rounded-lg border border-slate-300 font-medium hover:bg-slate-100">Cancel</button>
                              <button 
                                onClick={processMappedCSV} 
                                disabled={REQUIRED_FIELDS.some(f => !columnMapping[f.key])}
                                className="px-6 py-2.5 rounded-lg bg-slate-900 text-white font-bold hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                              >
                                Process Import <ArrowRightLeft className="w-4 h-4"/>
                              </button>
                           </div>
                        </div>
                     </div>
                  )}

                  {productTab === 'catalog' && (
                    <div className="space-y-6">
                      <div className="flex flex-wrap gap-4 p-4 bg-slate-50 rounded-xl border border-slate-200 items-center justify-between">
                        <div className="flex items-center gap-4 flex-1">
                            <div className="relative flex-1 max-w-md">
                              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400"/>
                              <input 
                                type="text" 
                                placeholder="Search by Name, SKU, Category..." 
                                className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg outline-none focus:border-curalina-500"
                                value={searchTerm}
                                onChange={e => setSearchTerm(e.target.value)}
                              />
                            </div>
                            <div className="relative">
                              <select 
                                className="pl-3 pr-8 py-2 border border-slate-200 rounded-lg appearance-none bg-white outline-none focus:border-curalina-500 cursor-pointer"
                                value={categoryFilter}
                                onChange={e => setCategoryFilter(e.target.value)}
                              >
                                  <option value="All">All Furniture Categories</option>
                                  {categories.filter(c => c !== 'All').map(c => <option key={c} value={c}>{c}</option>)}
                              </select>
                              <Filter className="absolute right-3 top-2.5 w-4 h-4 text-slate-400 pointer-events-none"/>
                            </div>
                            <div className="relative">
                              <select 
                                className="pl-3 pr-8 py-2 border border-slate-200 rounded-lg appearance-none bg-white outline-none focus:border-curalina-500 cursor-pointer"
                                value={priceRange}
                                onChange={e => setPriceRange(e.target.value as any)}
                              >
                                  <option value="All">Any Price</option>
                                  <option value="Low">Low (&lt;$500)</option>
                                  <option value="Medium">Medium</option>
                                  <option value="High">High (&gt;$1500)</option>
                              </select>
                              <DollarSign className="absolute right-3 top-2.5 w-4 h-4 text-slate-400 pointer-events-none"/>
                            </div>
                        </div>
                        <div className="text-sm text-slate-500 font-medium">
                            {filteredCatalog.length} Items Found
                        </div>
                      </div>

                      <div className="border border-slate-200 rounded-lg overflow-hidden bg-white">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-slate-50 text-slate-600 font-medium border-b border-slate-200">
                              <tr>
                                  <th className="p-4">Image</th>
                                  <th className="p-4">SKU</th>
                                  <th className="p-4">Product Name</th>
                                  <th className="p-4">Furniture Category</th>
                                  <th className="p-4">Supplier</th>
                                  <th className="p-4">Retail Price</th>
                                  <th className="p-4">Inventory</th>
                                  <th className="p-4">Actions</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                              {filteredCatalog.map(p => (
                                  <tr key={p.id} className="hover:bg-slate-50 group transition-colors">
                                    <td className="p-4">
                                        <div className="w-12 h-12 bg-slate-100 rounded overflow-hidden border border-slate-200 relative group/img">
                                          {p.imageUrl ? (
                                            <img 
                                              src={p.imageUrl} 
                                              alt={p.name} 
                                              className="w-full h-full object-cover"
                                              onError={(e) => {
                                                e.currentTarget.style.display = 'none';
                                                e.currentTarget.parentElement!.classList.add('flex', 'items-center', 'justify-center');
                                                const icon = document.createElement('div');
                                                icon.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-red-300"><path d="m21 21-9-9m9 10v-10a2 2 0 0 0-2-2h-10m-4 4 4 4m0 0 4-4m-4 4v10"/></svg>';
                                                e.currentTarget.parentElement!.appendChild(icon);
                                              }}
                                            />
                                          ) : (
                                            <div className="w-full h-full flex items-center justify-center text-slate-300">
                                              <ImageIcon className="w-5 h-5"/>
                                            </div>
                                          )}
                                          {/* Hover tool for URL inspection */}
                                          {p.imageUrl && (
                                            <div className="absolute inset-0 bg-black/70 text-white text-[8px] p-1 hidden group-hover/img:flex items-center justify-center break-all text-center">
                                              {p.imageUrl.startsWith('data:') ? 'Base64 Image' : 'External URL'}
                                            </div>
                                          )}
                                        </div>
                                    </td>
                                    <td className="p-4 font-mono text-xs text-slate-500">{p.sku || p.id}</td>
                                    <td className="p-4 font-medium text-slate-900">
                                        {p.name}
                                        {p.description && <div className="text-xs text-slate-400 truncate w-32">{p.description}</div>}
                                    </td>
                                    <td className="p-4">
                                        <span className="px-2 py-1 bg-slate-100 rounded text-xs border border-slate-200">{p.category}</span>
                                    </td>
                                    <td className="p-4 text-slate-600">{p.supplier || 'N/A'}</td>
                                    <td className="p-4 font-medium">
                                        {p.salePrice ? (
                                          <div>
                                              <span className="text-green-600">${p.salePrice}</span>
                                              <span className="text-xs text-slate-400 line-through ml-1">${p.price}</span>
                                          </div>
                                        ) : <span>${p.price}</span>}
                                    </td>
                                    <td className="p-4">
                                        <span className={`px-2 py-1 rounded text-xs font-medium ${p.stock > 0 ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
                                          {p.stock} Units
                                        </span>
                                    </td>
                                    <td className="p-4">
                                        <button className="text-slate-400 hover:text-curalina-600"><MoreVertical className="w-4 h-4"/></button>
                                    </td>
                                  </tr>
                              ))}
                              {filteredCatalog.length === 0 && (
                                  <tr>
                                    <td colSpan={8} className="p-12 text-center text-slate-400">
                                        No products found matching your filters.
                                    </td>
                                  </tr>
                              )}
                            </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  {productTab === 'single' && (
                    <form onSubmit={handleSubmitProduct} className="grid lg:grid-cols-2 gap-10">
                      <div className="space-y-6">
                        <div>
                          <label className="block text-sm font-medium text-slate-700 mb-2">Product Image</label>
                          <div className="relative aspect-square rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 hover:bg-slate-100 transition-colors group overflow-hidden">
                            {imagePreview ? <img src={imagePreview} className="w-full h-full object-cover" /> : <div className="flex flex-col items-center justify-center h-full text-slate-400"><ImageIcon className="w-10 h-10 mb-2"/><span className="text-sm">Upload to analyze</span></div>}
                            <input type="file" accept="image/*" onChange={handleImageUpload} className="absolute inset-0 opacity-0 cursor-pointer" />
                            {analyzing && <div className="absolute inset-0 bg-white/80 flex flex-col items-center justify-center text-curalina-600"><Loader2 className="w-8 h-8 animate-spin mb-2"/><span className="text-sm font-semibold">Analyzing...</span></div>}
                          </div>
                          
                          <div className="mt-4">
                            <label className="block text-sm font-medium text-slate-700 mb-1">Or Paste Image URL</label>
                            <input type="url" placeholder="https://..." className="w-full p-2 border rounded-lg bg-slate-50 text-sm" onChange={(e) => setImagePreview(e.target.value)} />
                          </div>
                        </div>
                      </div>
                      <div className="space-y-5">
                        <input type="text" placeholder="Product Name" required className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-curalina-500 outline-none bg-slate-50" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                        <input type="text" placeholder="SKU" className="w-full p-3 border rounded-lg bg-slate-50" value={formData.sku || ''} onChange={e => setFormData({...formData, sku: e.target.value})} />
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-xs text-slate-500 block mb-1">Furniture Category</label>
                            <select className="w-full p-3 border rounded-lg bg-slate-50" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})}>
                                <option disabled value="">Select Category</option>
                                {['Seating', 'Tables', 'Storage', 'Lighting', 'Decor', 'Rugs'].map(c => <option key={c} value={c}>{c}</option>)}
                            </select>
                          </div>
                          <input type="number" placeholder="Retail Price" className="p-3 border rounded-lg bg-slate-50 mt-5" value={formData.price || ''} onChange={e => setFormData({...formData, price: Number(e.target.value)})} />
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <input placeholder="W (in)" type="number" className="p-3 border rounded-lg bg-slate-50" onChange={e => setFormData({...formData, dimensions: {...formData.dimensions!, w: Number(e.target.value)}})} />
                          <input placeholder="D (in)" type="number" className="p-3 border rounded-lg bg-slate-50" onChange={e => setFormData({...formData, dimensions: {...formData.dimensions!, d: Number(e.target.value)}})} />
                          <input placeholder="H (in)" type="number" className="p-3 border rounded-lg bg-slate-50" onChange={e => setFormData({...formData, dimensions: {...formData.dimensions!, h: Number(e.target.value)}})} />
                        </div>
                        <textarea placeholder="Overview / Description" rows={4} className="w-full p-3 border rounded-lg bg-slate-50 text-sm text-slate-600" value={formData.description || ''} onChange={e => setFormData({...formData, description: e.target.value})} />
                        <button type="submit" className="w-full bg-slate-900 text-white py-3 rounded-lg font-bold hover:bg-slate-800 transition-colors flex items-center justify-center gap-2"><Plus className="w-5 h-5"/> Add to Catalog</button>
                      </div>
                    </form>
                  )}

                  {productTab === 'bulk_csv' && (
                    <div className="max-w-3xl mx-auto py-4">
                      <div className="text-center mb-8">
                        <div className="bg-curalina-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 text-curalina-600"><FileSpreadsheet className="w-8 h-8"/></div>
                        <h3 className="font-bold text-lg mb-2">Upload Product CSV</h3>
                        <p className="text-slate-500 mb-6 text-sm">Supports custom column mapping for all 38 system fields.</p>
                        
                        <div className="flex justify-center gap-4">
                          <button onClick={downloadCSVTemplate} className="inline-flex bg-white border border-slate-300 text-slate-700 px-4 py-3 rounded-lg font-medium hover:bg-slate-50 transition-colors items-center gap-2">
                            <Download className="w-4 h-4"/> Download Template
                          </button>
                          <label className="inline-flex cursor-pointer bg-slate-900 text-white px-6 py-3 rounded-lg font-medium hover:bg-slate-800 transition-colors items-center gap-2">
                            <Upload className="w-4 h-4"/> Select CSV File
                            <input type="file" accept=".csv" className="hidden" onChange={handleBulkImportCSV} />
                          </label>
                        </div>
                      </div>

                      {importErrors.length > 0 && (
                        <div className="mb-6 bg-red-50 border border-red-100 rounded-xl p-4 animate-in fade-in">
                          <div className="flex items-center gap-2 text-red-700 font-bold mb-2">
                            <AlertCircle className="w-5 h-5" /> Import Issues ({importErrors.length})
                          </div>
                          <div className="max-h-40 overflow-y-auto space-y-2 pr-2">
                            {importErrors.map((err, i) => (
                              <div key={i} className="text-sm bg-white p-2 rounded border border-red-100 text-red-600">
                                <span className="font-bold">Row {err.row}:</span> {err.message}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {csvPreview.length > 0 && (
                        <div className="text-left animate-in fade-in">
                          <div className="flex justify-between items-center mb-3">
                            <h4 className="font-bold text-slate-900 flex items-center gap-2"><Check className="w-5 h-5 text-green-500"/> Preview ({csvPreview.length} valid items)</h4>
                            <button onClick={confirmCSVImport} className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-green-700 shadow-sm">Confirm Import</button>
                          </div>
                          <div className="bg-slate-50 border border-slate-200 rounded-lg max-h-96 overflow-y-auto">
                              <table className="w-full text-xs">
                                <thead className="bg-slate-100 text-slate-600 sticky top-0">
                                    <tr>
                                      <th className="p-2">SKU</th><th className="p-2">Name</th><th className="p-2">Furniture Category</th>
                                      <th className="p-2">Supplier</th><th className="p-2">Price</th><th className="p-2">Inventory</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {csvPreview.map((p,i) => (
                                      <tr key={i} className="border-t border-slate-100">
                                        <td className="p-2 font-mono">{p.sku}</td>
                                        <td className="p-2 truncate max-w-[120px]" title={p.name}>{p.name}</td>
                                        <td className="p-2">{p.category}</td>
                                        <td className="p-2">{p.supplier}</td>
                                        <td className="p-2">${p.price}</td>
                                        <td className="p-2">{p.stock}</td>
                                      </tr>
                                    ))}
                                </tbody>
                              </table>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {productTab === 'bulk_img' && (
                    <div className="space-y-6">
                      {!processingFolder && detectedProducts.length === 0 && (
                        <div className="max-w-xl mx-auto text-center py-8">
                          <div className="bg-blue-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 text-blue-600"><FolderInput className="w-8 h-8"/></div>
                          <h3 className="font-bold text-lg mb-2">Smart SKU Image Connect</h3>
                          <p className="text-slate-500 mb-6 text-sm">
                            Organize folders by SKU: <strong>Category / SKU / Images</strong><br/>
                            We will automatically attach images to products with matching SKUs (case-insensitive).
                          </p>
                          <label className="inline-flex cursor-pointer bg-slate-900 text-white px-6 py-3 rounded-lg font-medium hover:bg-slate-800 transition-colors items-center gap-2">
                              <Folder className="w-4 h-4"/> Select Root Folder
                              {/* @ts-ignore */}
                              <input type="file" multiple webkitdirectory="" className="hidden" onChange={handleFolderUpload} />
                          </label>
                        </div>
                      )}
                      {processingFolder && <div className="text-center py-12 text-slate-500"><Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-curalina-600"/>Processing directory structure...</div>}
                      {detectedProducts.length > 0 && (
                        <div>
                          <div className="flex justify-between items-center mb-4">
                            <h4 className="font-bold text-slate-900 flex items-center gap-2"><Check className="w-5 h-5 text-green-500"/> {detectedProducts.length} Items Processed</h4>
                            <button onClick={confirmFolderImport} className="bg-green-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-green-700 shadow-sm">Confirm Changes</button>
                          </div>
                          <div className="border border-slate-200 rounded-lg overflow-hidden max-h-96 overflow-y-auto bg-slate-50">
                            <table className="w-full text-sm text-left">
                                <thead className="bg-slate-100 text-slate-600 sticky top-0">
                                  <tr>
                                    <th className="p-3">Action</th>
                                    <th className="p-3">Preview</th>
                                    <th className="p-3">SKU</th>
                                    <th className="p-3">Product Name</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {detectedProducts.map((p,i) => (
                                    <tr key={i} className="border-t border-slate-100 bg-white">
                                      <td className="p-3">
                                        {p.isUpdate ? (
                                          <span className="inline-flex items-center gap-1 px-2 py-1 bg-blue-50 text-blue-700 rounded text-xs border border-blue-100"><RefreshCcw className="w-3 h-3"/> Found SKU - Updating</span>
                                        ) : (
                                          <span className="inline-flex items-center gap-1 px-2 py-1 bg-slate-100 text-slate-500 rounded text-xs border border-slate-200"><Plus className="w-3 h-3"/> New SKU</span>
                                        )}
                                      </td>
                                      <td className="p-3 flex gap-1">
                                        <img src={p.imageUrl} className="w-10 h-10 rounded object-cover border border-slate-200"/>
                                        {p.images && p.images.length > 1 && (
                                          <span className="flex items-center justify-center w-10 h-10 bg-slate-100 text-slate-500 text-xs rounded border border-slate-200">+{p.images.length - 1}</span>
                                        )}
                                      </td>
                                      <td className="p-3 font-mono text-xs">{p.sku}</td>
                                      <td className="p-3 font-medium">{p.name}</td>
                                    </tr>
                                  ))}
                                </tbody>
                            </table>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}
            
            {/* OTHER SECTIONS (Overview, Analytics etc. rendered if active) */}
            {activeSection !== 'products' && (
               <div className="bg-card p-8 rounded-xl border border-slate-200 text-center text-slate-500">
                  <div className="mb-4 text-4xl">🚧</div>
                  <h3 className="text-xl font-bold text-slate-800 mb-2">Section Under Maintenance</h3>
                  <p>We updated the Products module. Other sections are reloading...</p>
                  <button onClick={() => setActiveSection('products')} className="mt-4 text-curalina-600 font-medium hover:underline">Go to Products</button>
               </div>
            )}
         </main>
      </div>
    </div>
  );
};
